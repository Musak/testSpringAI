package com.epam.ailoc.config;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.boot.web.client.RestClientCustomizer;
import org.springframework.boot.web.reactive.function.client.WebClientCustomizer;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;

import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;

import static org.slf4j.LoggerFactory.getLogger;

@Configuration
public class AppConfig {

    @Value("${spring.ai.vectorstore.pgvector.table-name:documents}")
    private String tableName;

    @Value("${spring.ai.vectorstore.pgvector.schema-name:public}")
    private String schemaName;

    @Value("${spring.ai.openai.api-key:}")
    private String apiKey;

    @Bean
    public ChatClient chatClient(ChatModel chatModel) {
        return ChatClient.builder(chatModel).build();
    }

    //Requires to override the default RestClient to add custom headers for PGVectors and Embeddings related requests
    @Bean
    public ClientHttpRequestInterceptor apiKeyHeaderInterceptor() {
        return (request, body, execution) -> {
            request.getHeaders().set("API-KEY", apiKey);
            request.getHeaders().remove("Authorization");
            return execution.execute(request, body);
        };
    }

    @Bean
    public RestClientCustomizer restClientCustomizer(ClientHttpRequestInterceptor apiKeyHeaderInterceptor) {
        return restClientBuilder -> restClientBuilder.requestInterceptor(apiKeyHeaderInterceptor);
    }

    // Interceptor to log outgoing HTTP requests/responses for RestClient
    @Bean
    public ClientHttpRequestInterceptor loggingInterceptor() {
        return (request, body, execution) -> {
            long start = System.currentTimeMillis();
            String uri = request.getURI().toString();
            String method = request.getMethod() == null ? "" : request.getMethod().name();
            String requestBody = body == null ? "" : new String(body, StandardCharsets.UTF_8);
            org.slf4j.Logger logger = getLogger("http-client-outgoing");
            logger.debug("Outgoing request: {} {} body={}", method, uri, requestBody);
            var response = execution.execute(request, body);
            long took = System.currentTimeMillis() - start;
            String responseBody = "<non-buffered>";
            logger.debug("Incoming response: {} {} status={} took={}ms body={}", method, uri, response.getStatusCode(), took, responseBody);
            return response;
        };
    }

    // Register loggingInterceptor for RestClient as well
    @Bean
    public RestClientCustomizer loggingRestClientCustomizer(ClientHttpRequestInterceptor loggingInterceptor) {
        return restClientBuilder -> restClientBuilder.requestInterceptor(loggingInterceptor);
    }

    // WebClient customizer to add exchange filter to log request/response
    @Bean
    public WebClientCustomizer webClientCustomizer() {
        return webClientBuilder -> {
            ExchangeFilterFunction logFilter = ExchangeFilterFunction.ofRequestProcessor(clientRequest -> {
                org.slf4j.Logger logger = getLogger("webclient-outgoing");
                logger.debug("WebClient request: {} {} headers={}", clientRequest.method(), clientRequest.url(), clientRequest.headers());
                return Mono.just(clientRequest);
            }).andThen(ExchangeFilterFunction.ofResponseProcessor(clientResponse -> {
                org.slf4j.Logger logger = getLogger("webclient-outgoing");
                logger.debug("WebClient response: status={} headers={}", clientResponse.statusCode(), clientResponse.headers().asHttpHeaders());
                return Mono.just(clientResponse);
            }));

            webClientBuilder.filters(filters -> filters.add(logFilter));
        };
    }
}