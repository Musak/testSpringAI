package com.epam.ailoc.assistant;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.prompt.SystemPromptTemplate;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

// added SLF4J imports
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
class Assistant {

    // create logger
    private static final Logger LOGGER = LoggerFactory.getLogger(Assistant.class);

    private final ChatClient chatClient;
    private final VectorStore vectorStore;

    @Value("${spring.ai.similarity.search.top-k}")
    private Integer topK;

    @Value("${spring.ai.similarity.search.threshold}")
    private Double similarityThresHold;

    public Assistant(ChatClient chatClient, VectorStore vectorStore) {
        this.chatClient = chatClient;
        this.vectorStore = vectorStore;
    }

    @GetMapping("/home")
    public String getAssistantSuggestion() {
        return "Welcome to the AI Assistant! Use /add-text to add text as document, or /ask to ask questions.";
    }

    @PostMapping("/add-text")
    public String addDocument(@RequestBody AddDocumentRequest request) {
        Document document = new Document(request.content(), request.metadata());

        // log incoming add document request
        LOGGER.info("Adding document (content length={} chars) with metadata={}",
                request.content() == null ? 0 : request.content().length(), request.metadata());
        try {
            vectorStore.add(List.of(document));
            LOGGER.info("Document added successfully");
            return "Document added successfully!";
        } catch (Exception ex) {
            LOGGER.error("Failed to add document to vector store", ex);
            return "Failed to add document: " + ex.getMessage();
        }
    }

    @PostMapping("/ask")
    public String askAssistant(@RequestBody AskAssistantRequest request) {


        // replaced System.out with logger
        LOGGER.debug("AskAssistant request query: {}", request.query());
        List<Document> relevantDocuments = vectorStore.similaritySearch(SearchRequest.builder()
                .query(request.query())
                .topK(topK)
                .similarityThreshold(similarityThresHold).build());

        String documentContent = relevantDocuments.stream()
                .map(Document::getText)
                .collect(Collectors.joining("\n"));

        String systemText = """
                You are an AI assistant. Use only the information provided in the context below to answer the user's question.
                Do not use any prior knowledge or make assumptions.

                Context:
                {context}

                Question: {question}

                Instructions:
                - If the answer is not present in the context, respond with: "I'm sorry, I don't have the information you are looking for."
                - Base your answer strictly on the context. Do not generate or infer information not found in the context.
                """;

        SystemPromptTemplate systemPromptTemplate = new SystemPromptTemplate(systemText);
        Message systemMessage = systemPromptTemplate.createMessage(
                Map.of("context", documentContent, "question", request.query()));

        Prompt prompt = Prompt.builder().messages(List.of(systemMessage)).build();
        // replaced System.out with logger
        LOGGER.debug("Prompt contents: {}", prompt.getContents());

        return chatClient.prompt(prompt).call().content();
    }

    record AddDocumentRequest(String content, Map<String, Object> metadata) {}
    record AskAssistantRequest(String query) {}
}
