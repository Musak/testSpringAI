package com.epam.ailoc;

import org.springframework.boot.SpringApplication;

public class TestAiSandboxApplication {

	public static void main(String[] args) {
		SpringApplication.from(AiSandboxApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
