package com.epam.ailoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.modulith.core.ApplicationModules;
import org.springframework.modulith.docs.Documenter;

@Import(TestcontainersConfiguration.class)
@SpringBootTest
class AiSandboxApplicationTests {

	@Test
	void contextLoads() {
		var am = ApplicationModules.of(AiSandboxApplication.class) ;
		am.verify();
		System.out.println(am);
		new Documenter(am)
				.writeModuleCanvases()
				.writeDocumentation();
	}

}
