# Langfuse Integration Verification Guide

## Prerequisites

1. **Langfuse is running** on `http://localhost:3000`
2. **Get your Langfuse credentials** from Settings > API Keys:
   - Public Key (starts with `pk-lf-...`)
   - Secret Key (starts with `sk-lf-...`)

## Configuration Steps

### 1. Set Environment Variables

**For local development (outside Docker):**

```bash
# Generate base64 encoded credentials
echo -n "your-public-key:your-secret-key" | base64

# Set environment variables
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:3000/api/public/otel
export OTEL_EXPORTER_OTLP_HEADERS="Authorization=Basic <generated-base64-string>"
```

**For Docker (already configured in docker-compose.yaml):**
- The environment variables are already set in docker-compose.yaml
- Make sure to update the base64 string with your actual credentials

### 2. Verify Configuration

Check that these properties are set in `application.properties`:
- `quarkus.otel.enabled=true`
- `quarkus.otel.exporter.otlp.endpoint` points to Langfuse
- `quarkus.langchain4j.tracing.include-prompt=true`
- `quarkus.langchain4j.tracing.include-completion=true`

### 3. Test the Connection

1. **Start your Quarkus application**
2. **Make a request** to trigger an AI operation:
   ```bash
   curl -X POST http://localhost:8080/travel/assistant \
     -H "Content-Type: application/json" \
     -d '{"query": "I want to travel to Budapest"}'
   ```

3. **Check application logs** for OpenTelemetry export messages:
   - Look for messages about OTLP export
   - Check for any connection errors

4. **Verify in Langfuse Dashboard**:
   - Go to `http://localhost:3000`
   - Navigate to "Traces" or "Observations"
   - You should see traces from your application

### 4. Troubleshooting

**No data appearing in Langfuse:**

1. **Check Langfuse is accessible:**
   ```bash
   curl http://localhost:3000/api/public/otel
   ```

2. **Verify credentials are correct:**
   - Check the base64 encoding is correct
   - Ensure public and secret keys are from the same Langfuse instance

3. **Check application logs:**
   - Enable debug logging: `quarkus.log.category."io.opentelemetry".level=DEBUG`
   - Look for export errors or connection failures

4. **Verify OpenTelemetry is enabled:**
   - Check logs for: "OpenTelemetry SDK initialized"
   - Verify no errors during startup

5. **Test with a simple trace:**
   - The application should automatically create traces for LangChain4j operations
   - If using REST endpoints, traces should be created automatically

**Common Issues:**

- **Wrong endpoint URL**: Should be `http://localhost:3000/api/public/otel` (not `/api/otel`)
- **Missing headers**: The Authorization header must be properly formatted
- **Network issues**: If running in Docker, use `host.docker.internal:3000` instead of `localhost:3000`
- **Langfuse not running**: Ensure Langfuse is started and accessible

## Expected Behavior

When working correctly:
- Every AI interaction creates a trace in Langfuse
- Traces include prompt and completion content
- You can see token usage, latency, and other metrics
- Traces are linked to the correct model and operation

