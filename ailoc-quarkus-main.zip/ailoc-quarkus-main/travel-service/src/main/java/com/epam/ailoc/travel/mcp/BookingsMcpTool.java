package com.epam.ailoc.travel.mcp;

import java.time.LocalDate;

import com.epam.ailoc.travel.model.Booking;
import com.epam.ailoc.travel.service.BookingService;
import com.epam.ailoc.travel.service.BookingService.CreateBookingRequest;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class BookingsMcpTool {

    @Inject
    BookingService bookingService;

    @Tool(
        name = "create_booking",
        description = "Create a new booking for a trip. Combines a hotel (optional) and/or flight (optional) into a booking. Returns the created booking in JSON format."
    )
    public Booking createBooking(
            @ToolArg(description = "Traveler's full name (required)") String travelerName,
            @ToolArg(description = "Traveler's email address") String travelerEmail,
            @ToolArg(description = "Name of the trip") String tripName,
            @ToolArg(description = "Hotel ID (optional, if booking includes a hotel)") Long hotelId,
            @ToolArg(description = "Flight ID (optional, if booking includes a flight)") Long flightId,
            @ToolArg(description = "Check-in date for hotel (YYYY-MM-DD format, optional)") LocalDate checkInDate,
            @ToolArg(description = "Check-out date for hotel (YYYY-MM-DD format, optional)") LocalDate checkOutDate,
            @ToolArg(description = "Booking status (optional, defaults to 'NEW')") String status) {
        
        CreateBookingRequest request = new CreateBookingRequest(
            hotelId,
            flightId,
            travelerName,
            travelerEmail,
            tripName,
            checkInDate,
            checkOutDate,
            status
        );
        
        return bookingService.createBooking(request);
    }
}

