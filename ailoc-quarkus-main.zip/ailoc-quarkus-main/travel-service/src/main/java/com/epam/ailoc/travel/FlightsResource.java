package com.epam.ailoc.travel;

import java.time.LocalDate;
import java.util.List;

import com.epam.ailoc.travel.model.Flight;
import com.epam.ailoc.travel.repository.FlightRepository;

import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/travel/flights")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class FlightsResource {

    @Inject
    FlightRepository flightRepository;

    @GET
    public List<Flight> searchFlights(
            @QueryParam("departure") String departure,
            @QueryParam("arrival") String arrival,
            @QueryParam("departureDate") LocalDate departureDate) {
        return flightRepository.search(departure, arrival, departureDate);
    }
}

