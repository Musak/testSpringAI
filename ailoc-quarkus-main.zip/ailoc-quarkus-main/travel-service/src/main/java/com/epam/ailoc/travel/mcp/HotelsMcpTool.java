package com.epam.ailoc.travel.mcp;

import java.util.List;

import com.epam.ailoc.travel.model.Hotel;
import com.epam.ailoc.travel.repository.HotelRepository;
import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class HotelsMcpTool {

    @Inject
    HotelRepository hotelRepository;

    @Tool(
        name = "search_hotels",
        description = "Search for hotels by city, country, and minimum rating. Returns a list of available hotels matching the criteria in JSON format."
    )
    public List<Hotel> searchHotels(
            @ToolArg(description = "City name where to search for hotels") String city,
            @ToolArg(description = "Country name where to search for hotels") String country,
            @ToolArg(description = "Minimum rating (0.0 to 5.0)") Double minRating) {
        return hotelRepository.search(city, country, minRating);
    }
}

