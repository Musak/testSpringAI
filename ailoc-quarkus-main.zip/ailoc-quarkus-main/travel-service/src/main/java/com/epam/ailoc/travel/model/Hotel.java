package com.epam.ailoc.travel.model;

import java.math.BigDecimal;

import io.quarkus.hibernate.orm.panache.PanacheEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "hotels")
public class Hotel extends PanacheEntity {

    @Column(nullable = false)
    public String name;

    @Column(nullable = false)
    public String city;

    @Column(nullable = false)
    public String country;

    @Column(name = "price_per_night")
    public BigDecimal pricePerNight;

    @Column
    public Double rating;
}

