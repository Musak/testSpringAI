package com.epam.ailoc.travel.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

import io.quarkus.hibernate.orm.panache.PanacheEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "flights")
public class Flight extends PanacheEntity {

    @Column(nullable = false)
    public String airline;

    @Column(name = "flight_number", nullable = false, unique = true)
    public String flightNumber;

    @Column(nullable = false)
    public String departure;

    @Column(nullable = false)
    public String arrival;

    @Column(name = "departure_date", nullable = false)
    public LocalDate departureDate;

    @Column(name = "departure_time")
    public LocalTime departureTime;

    @Column(name = "arrival_time")
    public LocalTime arrivalTime;

    @Column
    public BigDecimal price;
}

