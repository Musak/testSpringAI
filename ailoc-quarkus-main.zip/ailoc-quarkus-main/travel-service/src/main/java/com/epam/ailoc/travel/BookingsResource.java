package com.epam.ailoc.travel;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.epam.ailoc.travel.model.Booking;
import com.epam.ailoc.travel.service.BookingService;
import com.epam.ailoc.travel.service.BookingService.CreateBookingRequest;

import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/travel/bookings")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class BookingsResource {

    @Inject
    BookingService bookingService;

    @POST
    public Response createBooking(CreateBookingRequest request) {
        try {
            Booking booking = bookingService.createBooking(request);
            return Response.status(Response.Status.CREATED).entity(toResponse(booking)).build();
        } catch (jakarta.ws.rs.NotFoundException e) {
            return Response.status(Response.Status.NOT_FOUND).entity(e.getMessage()).build();
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        } catch (Exception e) {
            return Response.serverError().entity("Failed to create booking: " + e.getMessage()).build();
        }
    }

    private BookingResponse toResponse(Booking booking) {
        return new BookingResponse(
                booking.id,
                booking.tripName,
                booking.travelerName,
                booking.travelerEmail,
                booking.hotel != null ? booking.hotel.id : null,
                booking.flight != null ? booking.flight.id : null,
                booking.checkInDate,
                booking.checkOutDate,
                booking.status,
                booking.totalPrice);
    }

    public record BookingResponse(
            Long id,
            String tripName,
            String travelerName,
            String travelerEmail,
            Long hotelId,
            Long flightId,
            LocalDate checkInDate,
            LocalDate checkOutDate,
            String status,
            BigDecimal totalPrice) {
    }
}

