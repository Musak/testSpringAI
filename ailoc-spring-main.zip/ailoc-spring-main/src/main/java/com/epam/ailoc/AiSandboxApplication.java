package com.epam.ailoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiSandboxApplication {

	public static void main(String[] args) {
		SpringApplication.run(AiSandboxApplication.class, args);
	}

}
