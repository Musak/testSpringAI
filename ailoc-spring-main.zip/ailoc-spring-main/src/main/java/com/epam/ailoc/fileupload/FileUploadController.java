package com.epam.ailoc.fileupload;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

@RestController
@RequestMapping("/add-document")
public class FileUploadController {

    // create logger
    private static final Logger LOGGER = LoggerFactory.getLogger(FileUploadController.class);


    private final VectorStore vectorStore;

    public FileUploadController(VectorStore vectorStore) {
        this.vectorStore = vectorStore;
    }

    @PostMapping
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
            String content = new String(file.getBytes(), StandardCharsets.UTF_8);
            Document document = new Document(content, Collections.singletonMap("filename", file.getOriginalFilename()));
            LOGGER.info("Adding Content: {}", content);

            vectorStore.add(Collections.singletonList(document));

            return ResponseEntity.ok("File uploaded and content stored successfully!");
        } catch (IOException e) {
            return ResponseEntity.badRequest().body("Failed to read file: " + e.getMessage());
        }
    }
} 