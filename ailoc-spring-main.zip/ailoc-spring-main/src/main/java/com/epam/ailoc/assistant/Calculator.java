package com.epam.ailoc.assistant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

@Component
public class Calculator {

    private static final Logger LOGGER = LoggerFactory.getLogger(Calculator.class);

    @Tool(
            name = "add",
            description = "Add two integers and return their sum. Signature: add(a: int, b: int) -> int."
    )
    public int add(@ToolParam(description = "Number in int") int a, @ToolParam(description = "Number in int") int b) {

        LOGGER.info("Received websocket message: %s + %s ", a, b);
        return a + b;
    }

    @Tool(
            name = "subtract",
            description = "Subtract second integer from first and return the result. Signature: subtract(a: int, b: int) -> int."
    )
    public int subtract(int a, int b) {
        return a - b;
    }

    @Tool(
            name = "multiply",
            description = "Multiply two integers and return the product. Signature: multiply(a: int, b: int) -> int."
    )
    public int multiply(int a, int b) {
        return a * b;
    }

    @Tool(
            name = "divide",
            description = "Divide first integer by second and return integer quotient. Throws IllegalArgumentException on division by zero. Signature: divide(a: int, b: int) -> int."
    )
    public int divide(int a, int b) {
        if (b == 0) {
            throw new IllegalArgumentException("Division by zero is not allowed.");
        }
        return a / b;
    }
}
