package com.epam.ailoc.config;

import io.micrometer.observation.ObservationRegistry;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

@Component
public class ChatModelCompletionContentObservationFilterRegistrar implements ApplicationListener<ContextRefreshedEvent> {

    private final ObservationRegistry observationRegistry;

    public ChatModelCompletionContentObservationFilterRegistrar(ObservationRegistry observationRegistry) {
        this.observationRegistry = observationRegistry;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        // Register filter instance after registry exists
        observationRegistry.observationConfig().observationFilter(new ChatModelCompletionContentObservationFilter());
    }
}
