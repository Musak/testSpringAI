package com.epam.ailoc.travelmcp.mcp;

import java.time.LocalDate;
import java.util.List;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Service;

import com.epam.ailoc.travelmcp.travel.model.Flight;
import com.epam.ailoc.travelmcp.travel.repository.FlightRepository;

/**
 * MCP service for flight search functionality.
 * This class exposes flight search as an MCP tool, reusing the same repository
 * as the FlightController but keeping MCP configuration separate.
 */
@Service
public class FlightMcpService {

    private final FlightRepository flightRepository;

    public FlightMcpService(FlightRepository flightRepository) {
        this.flightRepository = flightRepository;
    }

    @Tool(description = "Search flights by optional departure city, arrival city, and departure date.")
    public List<Flight> searchFlights(
            @ToolParam(description = "Departure city filter", required = false) String departure,
            @ToolParam(description = "Arrival city filter", required = false) String arrival,
            @ToolParam(description = "Departure date filter (format: YYYY-MM-DD)", required = false) LocalDate departureDate) {
        return flightRepository.search(departure, arrival, departureDate);
    }
}

