package com.epam.ailoc.travelmcp.mcp;

import java.util.List;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Service;

import com.epam.ailoc.travelmcp.travel.model.Hotel;
import com.epam.ailoc.travelmcp.travel.repository.HotelRepository;

/**
 * MCP service for hotel search functionality.
 * This class exposes hotel search as an MCP tool, reusing the same repository
 * as the HotelController but keeping MCP configuration separate.
 */
@Service
public class HotelMcpService {

    private final HotelRepository hotelRepository;

    public HotelMcpService(HotelRepository hotelRepository) {
        this.hotelRepository = hotelRepository;
    }

    @Tool(description = "Search hotels by optional city, country, and minimum rating.")
    public List<Hotel> searchHotels(
            @ToolParam(description = "City filter", required = false) String city,
            @ToolParam(description = "Country filter", required = false) String country,
            @ToolParam(description = "Minimum rating filter", required = false) Double minRating) {
        return hotelRepository.search(city, country, minRating);
    }
}

