package com.epam.ailoc.travelmcp.travel;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.epam.ailoc.travelmcp.travel.model.Booking;
import com.epam.ailoc.travelmcp.travel.service.BookingService;
import com.epam.ailoc.travelmcp.travel.service.BookingService.CreateBookingRequest;

import java.time.LocalDate;

@RestController
@RequestMapping("/travel/bookings")
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping
    public ResponseEntity<?> createBooking(@RequestBody CreateBookingRequest request) {
        try {
            Booking booking = bookingService.createBooking(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(toResponse(booking));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to create booking: " + e.getMessage());
        }
    }

    private BookingResponse toResponse(Booking booking) {
        return new BookingResponse(
                booking.getId(),
                booking.getTripName(),
                booking.getTravelerName(),
                booking.getTravelerEmail(),
                booking.getHotel() != null ? booking.getHotel().getId() : null,
                booking.getFlight() != null ? booking.getFlight().getId() : null,
                booking.getCheckInDate(),
                booking.getCheckOutDate(),
                booking.getStatus(),
                booking.getTotalPrice());
    }

    public record BookingResponse(
            Long id,
            String tripName,
            String travelerName,
            String travelerEmail,
            Long hotelId,
            Long flightId,
            LocalDate checkInDate,
            LocalDate checkOutDate,
            String status,
            java.math.BigDecimal totalPrice) {
    }
}

