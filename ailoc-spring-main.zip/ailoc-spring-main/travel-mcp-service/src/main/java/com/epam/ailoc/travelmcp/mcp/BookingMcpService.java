package com.epam.ailoc.travelmcp.mcp;

import java.time.LocalDate;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Service;

import com.epam.ailoc.travelmcp.travel.model.Booking;
import com.epam.ailoc.travelmcp.travel.service.BookingService;

/**
 * MCP service for booking creation functionality.
 * This class exposes booking creation as an MCP tool, reusing the same service
 * as the BookingController but keeping MCP configuration separate.
 */
@Service
public class BookingMcpService {

    private final BookingService bookingService;

    public BookingMcpService(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @Tool(description = "Create a booking for a trip. Can include hotel and/or flight. Traveler name is required.")
    public Booking createBooking(
            @ToolParam(description = "Hotel ID (optional)", required = false) Long hotelId,
            @ToolParam(description = "Flight ID (optional)", required = false) Long flightId,
            @ToolParam(description = "Traveler name (required)", required = true) String travelerName,
            @ToolParam(description = "Traveler email (optional)", required = false) String travelerEmail,
            @ToolParam(description = "Trip name (optional)", required = false) String tripName,
            @ToolParam(description = "Check-in date (format: YYYY-MM-DD, optional)", required = false) LocalDate checkInDate,
            @ToolParam(description = "Check-out date (format: YYYY-MM-DD, optional)", required = false) LocalDate checkOutDate,
            @ToolParam(description = "Booking status (optional, defaults to NEW)", required = false) String status) {
        
        BookingService.CreateBookingRequest request = new BookingService.CreateBookingRequest(
                hotelId,
                flightId,
                travelerName,
                travelerEmail,
                tripName,
                checkInDate,
                checkOutDate,
                status);
        
        return bookingService.createBooking(request);
    }
}

