package com.epam.ailoc.travelmcp.travel.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.epam.ailoc.travelmcp.travel.model.Flight;

@Repository
public interface FlightRepository extends JpaRepository<Flight, Long> {

    @Query(value = "SELECT * FROM flights f WHERE " +
           "(CASE WHEN :departure IS NULL THEN TRUE ELSE LOWER(f.departure) = LOWER(CAST(:departure AS VARCHAR)) END) AND " +
           "(CASE WHEN :arrival IS NULL THEN TRUE ELSE LOWER(f.arrival) = LOWER(CAST(:arrival AS VARCHAR)) END) AND " +
           "(CASE WHEN :departureDate IS NULL THEN TRUE ELSE f.departure_date = CAST(:departureDate AS DATE) END)", 
           nativeQuery = true)
    List<Flight> search(@Param("departure") String departure,
                        @Param("arrival") String arrival,
                        @Param("departureDate") LocalDate departureDate);
}

