package com.epam.ailoc.travelmcp.travel.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.epam.ailoc.travelmcp.travel.model.Booking;
import com.epam.ailoc.travelmcp.travel.model.Flight;
import com.epam.ailoc.travelmcp.travel.model.Hotel;
import com.epam.ailoc.travelmcp.travel.repository.BookingRepository;
import com.epam.ailoc.travelmcp.travel.repository.FlightRepository;
import com.epam.ailoc.travelmcp.travel.repository.HotelRepository;
import com.epam.ailoc.travelmcp.travel.service.BookingService.CreateBookingRequest;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private final HotelRepository hotelRepository;
    private final FlightRepository flightRepository;

    public BookingService(BookingRepository bookingRepository,
                         HotelRepository hotelRepository,
                         FlightRepository flightRepository) {
        this.bookingRepository = bookingRepository;
        this.hotelRepository = hotelRepository;
        this.flightRepository = flightRepository;
    }

    @Transactional
    public Booking createBooking(CreateBookingRequest request) {
        if (request == null) {
            throw new IllegalArgumentException("Booking request cannot be null");
        }
        if (request.travelerName() == null || request.travelerName().isBlank()) {
            throw new IllegalArgumentException("Traveler name is required");
        }

        Hotel hotel = null;
        if (request.hotelId() != null) {
            hotel = hotelRepository.findById(request.hotelId())
                    .orElseThrow(() -> new IllegalArgumentException("Hotel not found for id: " + request.hotelId()));
        }

        Flight flight = null;
        if (request.flightId() != null) {
            flight = flightRepository.findById(request.flightId())
                    .orElseThrow(() -> new IllegalArgumentException("Flight not found for id: " + request.flightId()));
        }

        Booking booking = new Booking();
        booking.setHotel(hotel);
        booking.setFlight(flight);
        booking.setTravelerName(request.travelerName());
        booking.setTravelerEmail(request.travelerEmail());
        booking.setTripName(request.tripName());
        booking.setCheckInDate(request.checkInDate());
        booking.setCheckOutDate(request.checkOutDate());
        booking.setStatus(request.status());
        booking.setTotalPrice(calculateTotalPrice(hotel, flight, request.checkInDate(), request.checkOutDate()));

        return bookingRepository.save(booking);
    }

    private BigDecimal calculateTotalPrice(Hotel hotel, Flight flight, LocalDate checkIn, LocalDate checkOut) {
        BigDecimal total = BigDecimal.ZERO;

        if (hotel != null && hotel.getPricePerNight() != null && checkIn != null && checkOut != null) {
            long nights = ChronoUnit.DAYS.between(checkIn, checkOut);
            if (nights < 0) {
                throw new IllegalArgumentException("checkOutDate must be after checkInDate");
            }
            total = total.add(hotel.getPricePerNight().multiply(BigDecimal.valueOf(Math.max(nights, 0))));
        }

        if (flight != null && flight.getPrice() != null) {
            total = total.add(flight.getPrice());
        }

        return total.compareTo(BigDecimal.ZERO) > 0 ? total : null;
    }

    public record CreateBookingRequest(
            Long hotelId,
            Long flightId,
            String travelerName,
            String travelerEmail,
            String tripName,
            LocalDate checkInDate,
            LocalDate checkOutDate,
            String status) {
    }
}

