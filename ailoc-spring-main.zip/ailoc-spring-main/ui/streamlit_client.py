import streamlit as st
import requests
import json
import os

API_URL = os.environ.get("API_URL", "http://localhost:8080")
print("API_URL:", os.environ.get("API_URL"))

st.set_page_config(page_title="AI Assistant Document processing", layout="centered")
st.title("AI Assistant Document processing")

email = "alice@epam.com"

# Authentication
if "user_email" not in st.session_state:
    st.sidebar.title("Login")
    email = st.sidebar.radio(
        "Select your user",
        ("alice@epam.com", "bob@epam.com"),
        index=0,
    )
    if st.sidebar.button("Login"):
        st.session_state["user_email"] = email
        st.rerun()

if "user_email" in st.session_state:
    st.sidebar.markdown(f"**Logged in as:** {st.session_state['user_email']}")
    if st.sidebar.button("Logout"):
        del st.session_state["user_email"]
        if "messages" in st.session_state:
            del st.session_state["messages"]
        st.rerun()

menu = st.sidebar.radio("Navigation", ["Ask Assistant", "Upload Document"])

if "user_email" in st.session_state:
    if menu == "Ask Assistant":
        st.header("Ask the Assistant")
        question = st.text_area("Enter your question:")
        if st.button("Ask"):
            if question.strip():
                with st.spinner("Getting answer..."):
                    try:
                        print("API_URL:", os.environ.get("API_URL"))
                        print("query ", question)
                        resp = requests.post(f"{API_URL}/ask", json={"query": question})
                        if resp.ok:
                            st.success(resp.json().get("answer", "No answer found."))
                        else:
                            st.error(f"Error: {resp.text}")
                    except Exception as e:
                        st.error(f"Request failed: {e}")
            else:
                st.warning("Please enter a question.")

    elif menu == "Upload Document":
        st.header("Upload a Document")
        tab1, tab2 = st.tabs(["Text Upload", "File Upload"])

        with tab1:
            doc_content = st.text_area("Document content:")
            metadata_str = st.text_area("Metadata (JSON, optional):", '{"source": "manual", "document_id": "0", '
                                                                      '"filename":"None", "content_type":"text"}')
            if st.button("Upload Text Document"):
                try:
                    metadata = json.loads(metadata_str) if metadata_str.strip() else {}
                    resp = requests.post(f"{API_URL}/add-text", json={"content": doc_content, "metadata": metadata})
                    if resp.ok:
                        st.success(resp.text)
                    else:
                        st.error(f"Error: {resp.text}")
                except json.JSONDecodeError:
                    st.error("Invalid JSON in metadata.")
                except Exception as e:
                    st.error(f"Request failed: {e}")

        with tab2:
            uploaded_file = st.file_uploader("Choose a file to upload")
            if st.button("Upload File"):
                if uploaded_file:
                    files = {"file": (uploaded_file.name, uploaded_file.getvalue(), uploaded_file.type)}
                    try:
                        print("Uploading file:", files)
                        resp = requests.post(f"{API_URL}/add-document", files=files)
                        if resp.ok:
                            st.success(resp.text)
                        else:
                            st.error(f"Error: {resp.text}")
                    except Exception as e:
                        st.error(f"Request failed: {e}")
                else:
                    st.warning("Please select a file to upload.")