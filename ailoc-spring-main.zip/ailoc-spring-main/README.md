# LO AI Sandbox Application

This repository contains a small Spring Boot application that demonstrates a Retrieval-Augmented Generation (RAG) flow using Spring AI and PostgreSQL with the pgvector extension.

What this app does (current state)

*   Add text documents (JSON) or upload files (multipart) and store them in a pgvector-backed vector store.
*   Query an AI model using stored documents as context (RAG-style) via a simple HTTP API.
*   Uses SLF4J/Logback for logging. A `RequestIdFilter` injects `X-Request-ID` and populates MDC with `requestId` for tracing.
*   Outgoing HTTP requests are logged by named loggers: `http-client-outgoing` (RestClient) and `webclient-outgoing` (WebClient).

Main HTTP endpoints (implemented in `Assistant.java` and `FileUploadController.java`)

*   GET /travel — basic tool call
*   POST /add-text — JSON body { "content": "...", "metadata": { ... } }
*   POST /ask — JSON body { "query": "..." }
*   POST /add-document — multipart file upload param `file` (stores file content and filename metadata)

Quick start (local)

1.  Build

    ```bash
    ./mvnw -DskipTests package
    ```

2.  Run

    ```bash
    java -jar target/ailoc-0.0.1-SNAPSHOT.jar
    ```

3.  Example requests

    ```bash
    curl -X POST http://localhost:8080/travel \
      -H "Content-Type: application/json" \
      -d '{"query":"Hello I want to travel to Budapest, but I have to go using Frankfurt as a connection. traveling to Frankfurt is 100 eur, from Frankfurt to Budapest 200 eur. What is the total amount that I have to spend on this travel?"}'
    ```

## Travel Services (Hotels, Flights, Bookings)

Search hotels:
```bash
curl -X GET "http://localhost:8081/travel/hotels?city=Budapest&minRating=4.0" \
  -H "Accept: application/json"
```

Search flights:
```bash
curl -X GET "http://localhost:8081/travel/flights?departure=New%20York&arrival=Budapest" \
  -H "Accept: application/json"
```

Create a booking (link hotel + flight):
```bash
curl -X POST http://localhost:8081/travel/bookings \
  -H "Content-Type: application/json" \
  -d '{
    "hotelId": 1,
    "flightId": 1,
    "travelerName": "Ada Lovelace",
    "travelerEmail": "ada@example.com",
    "tripName": "Business Trip",
    "checkInDate": "2025-02-01",
    "checkOutDate": "2025-02-05",
    "status": "NEW"
  }'
```
## Travel assistant
You can ask travel-related questions to the assistant:
Step 1: Search for hotels and flights

```bash
curl -X POST http://localhost:8080/travel \
-H "Content-Type: application/json" \
-d '{"query":"Hello currently I am in Frankfurt, and I want to travel to Budapest. Taxi to airport is 100 euro, from Frankfurt airport to Budapest is 200 eur. What is the total amount that I have to spend on this travel?  What is the Hotel name where I will be sleeping?  What is the flight that I will use for this trip ?","conversationId": "user-123"}'
```
Step 2: Specify travel details

```bash
curl -X POST http://localhost:8080/travel \
-H "Content-Type: application/json" \
-d '{"query":"departure date is 2025-12-25 from Frankfurt and I will travel alone, any hotel is good for me","conversationId": "user-123"}'
```

Step 3: Proceed to booking hotel
```bash
curl -X POST http://localhost:8080/travel \
-H "Content-Type: application/json" \
-d '{"query":"proceed booking hotel the rest I will manage","conversationId": "user-123"}'
```

## RAG add text / ask example requests
```bash
curl -X POST http://localhost:8080/add-text \
  -H "Content-Type: application/json" \
  -d '{"content":"The capital of France is Paris.","metadata":{"source":"manual"}}'
```

```bash
curl -X POST http://localhost:8080/ask \
  -H "Content-Type: application/json" \
  -d '{"query":"What is the capital of France?"}'
```

```bash
curl -F "file=@/path/to/file.txt" http://localhost:8080/add-document
```

Postgres + pgvector persistence (Docker / Podman)

If you run Postgres via Docker/Podman you must persist the data directory to avoid losing pgvector data after container rebuilds.

Minimal `docker-compose` Postgres service snippet (use in your compose file):

```yaml
services:
  postgres:
    image: pgvector/pgvector:0.8.0-pg17
    environment:
      POSTGRES_DB: rag_database
      POSTGRES_USER: raguser
      POSTGRES_PASSWORD: ragpassword
    volumes:
      - pg-data:/var/lib/postgresql/data
    ports:
      - "6432:5432"

volumes:
  pg-data:
    name: ailoc_pg_data
```

Important:

*   Do not run `docker-compose down -v` (that deletes volumes). Use `docker-compose down` or `docker-compose stop` to preserve data.
*   Alternatively use a host bind mount (e.g. `./pg-data:/var/lib/postgresql/data`) but ensure file permissions allow Postgres to write.

Make sure pgvector extension exists and table schema matches your configuration. Example once-off SQL:

```sql
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS hstore;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS vector_store (
  id uuid DEFAULT uuid_generate_v4() PRIMARY KEY,
  content text,
  metadata jsonb,
  embedding vector(1536)
);
CREATE INDEX IF NOT EXISTS ON vector_store USING HNSW (embedding vector_cosine_ops);
```

Logging and sending logs to ELK / Logstash

*   The project uses Logback and includes a Logstash TCP appender in `src/main/resources/logback-spring.xml`.
*   Configure the Logstash destination using environment properties. Example change in `logback-spring.xml`:

```xml
<destination>${LOGSTASH_HOST:-localhost}:${LOGSTASH_PORT:-5100}</destination>
```

*   If your ELK/Logstash runs in Podman, either run the Spring app in the same Podman network or set `LOGSTASH_HOST` to an address reachable from the Spring app container (for macOS, `host.docker.internal` is often useful).
*   You can also run the Spring app locally and forward logs to the host Logstash at `localhost:5100`.

Viewing outgoing HTTP traffic (requests/responses)

*   To see outgoing RestClient/WebClient calls enable DEBUG for `http-client-outgoing` and `webclient-outgoing` (already present in `logback-spring.xml` and `application.yml`).
*   For low-level wire logs (Apache HttpClient or Reactor Netty), enable the following in `application.yml` or as env properties (debug only):

```yaml
logging:
  level:
    org.apache.http.wire: DEBUG
    org.apache.http.headers: DEBUG
    reactor.netty.http.client: DEBUG
    okhttp3: DEBUG
    http-client-outgoing: DEBUG
    webclient-outgoing: DEBUG
```

*   Warning: wire logging can emit raw/binary payloads and sensitive data. Use only for debugging.

MDC and request ID

*   `RequestIdFilter` adds `X-Request-ID` and sets `requestId` in MDC. Logback pattern includes `[%X{requestId}]` so each log line contains the request id for tracing.
*   Outgoing HTTP logging attempts to run within the servlet thread so the request id appears on outgoing logs as well.

Troubleshooting common errors

1.  Proxying final method / GenericFilterBean.init NPE

    You may see an error about proxying the final `GenericFilterBean.init` method followed by a NPE in `GenericFilterBean.init` referencing logger being null. Typical fixes:

    *   Prefer JDK interface proxies: set `spring.aop.proxy-target-class=false` in `application.yml`.
    *   Register filters explicitly with `FilterRegistrationBean` to avoid the servlet container creating its own instance or dealing with proxies.
    *   Make loggers static final where possible so container-instantiated filters don't hit uninitialized instance fields.

2.  BadSqlGrammarException on INSERT for pgvector

    If SQL like `INSERT INTO public.vector_store (...) ...` fails:

    *   Confirm the table and column types (embedding vector dimensions) match expectations.
    *   Confirm `metadata` column type is `jsonb` when code casts to `?::jsonb`.
    *   Verify you use a Postgres JDBC driver version compatible with your Postgres server.
    *   Inspect the SQL used by the PgVector integration and ensure `table-name`/`schema-name` in `application.yml` match the DB.

If you'd like, I can make any of the following changes now:

*   Add a small `docker-compose.yml` that wires Spring, Postgres (with named volume) and a Logstash service that forwards to your Podman ELK.
*   Update `logback-spring.xml` in the repo to reference `${LOGSTASH_HOST}` / `${LOGSTASH_PORT}` properties.
*   Add a `FilterRegistrationBean` example to avoid proxying issues.
*   Add a tiny SQL validation script to check the `vector_store` table shape.

---

(End of updated README)

Docker Compose usage

This repository already contains a `docker-compose.yaml` that defines services for the Spring app, a `pgvector` Postgres image, and a `frontend` (UI). It references an external `elk` network so containers can send logs to your ELK/Logstash instance.

Prerequisites
- Docker Engine or Podman with Compose support installed.
- If using Podman, modern versions support `podman compose` (or use `podman-compose` depending on your setup).
- An `elk` network reachable by the compose stack. If you don't have one, create it (Docker example):

```bash
# Docker
docker network create elk

# Podman
podman network create elk
```

Start the stack
- Start only the Spring app and Postgres (use the `local-spring` and `local-pg` profiles defined in the compose file):

```bash
# Docker Compose (Docker CLI)
docker compose --profile local-spring --profile local-pg up -d

# Podman (if using podman-compose or podman native compose)
# podman compose --profile local-spring --profile local-pg up -d
# or
# podman-compose --profile local-spring --profile local-pg up -d
```

- Start everything including UI:

```bash
docker compose --profile local-spring --profile local-pg --profile local-ui up -d
```

Stop the stack

```bash
docker compose down                      # preserves volumes
docker compose down --volumes            # removes volumes (DON'T use if you wish to keep pgvector data)
```

View logs

```bash
docker compose logs -f spring-boot-app      # follow Spring app logs
docker compose logs -f postgres-pgvector    # follow postgres logs
```

Environment variables and Logstash/ELK
- The compose file sets the Spring datasource to `jdbc:postgresql://postgres-pgvector:6432/rag_database` by default. If you run Postgres elsewhere, set `SPRING_DATASOURCE_URL` when starting the containers.
- The application reads Logstash host/port from the `LOGSTASH_HOST` and `LOGSTASH_PORT` environment variables (if you update `logback-spring.xml` as suggested earlier). Example to run with environment overrides:

```bash
LOGSTASH_HOST=elk-logstash LOGSTASH_PORT=5100 docker compose --profile local-spring --profile local-pg up -d
```

Notes about networks and Podman
- The compose file references an external network named `elk`. If your Podman-managed ELK stack created a different network name, either update `docker-compose.yaml` or create a network alias named `elk` connecting the stacks.
- When the Spring container and Logstash are on the same compose network, use the Logstash service name (for example `elk-logstash`) as `LOGSTASH_HOST`. If Logstash runs on the host, use `host.docker.internal` from containers on macOS.

Preserving pgvector data
- The compose uses a named volume `pgvector_data` mounted to `/var/lib/postgresql/data`. Avoid `docker compose down --volumes` if you want to keep data.
- To back up the Postgres volume manually, use `pg_dump` or create a host bind-mount to a persistent folder (e.g. `./pg-data:/var/lib/postgresql/data`) but ensure proper permissions.

Quick troubleshooting commands

```bash
# Check container health and state
docker compose ps

# Check networks
docker network ls

# Inspect the 'elk' network and connected containers
docker network inspect elk
```

To start MCP Inspector use 
```bash
npx @modelcontextprotocol/inspector
```

