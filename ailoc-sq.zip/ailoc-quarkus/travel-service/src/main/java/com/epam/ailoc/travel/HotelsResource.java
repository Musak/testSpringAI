package com.epam.ailoc.travel;

import java.util.List;

import com.epam.ailoc.travel.model.Hotel;
import com.epam.ailoc.travel.repository.HotelRepository;

import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/travel/hotels")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class HotelsResource {

    @Inject
    HotelRepository hotelRepository;

    @GET
    public List<Hotel> searchHotels(
            @QueryParam("city") String city,
            @QueryParam("country") String country,
            @QueryParam("minRating") Double minRating) {
        return hotelRepository.search(city, country, minRating);
    }
}

