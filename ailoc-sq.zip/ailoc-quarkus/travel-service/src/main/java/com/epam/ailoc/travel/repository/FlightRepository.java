package com.epam.ailoc.travel.repository;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.epam.ailoc.travel.model.Flight;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class FlightRepository implements PanacheRepository<Flight> {

    public List<Flight> search(String departure, String arrival, LocalDate departureDate) {
        StringBuilder query = new StringBuilder("1=1");
        Map<String, Object> params = new HashMap<>();

        if (departure != null && !departure.isBlank()) {
            query.append(" and lower(departure) = :departure");
            params.put("departure", departure.toLowerCase());
        }
        if (arrival != null && !arrival.isBlank()) {
            query.append(" and lower(arrival) = :arrival");
            params.put("arrival", arrival.toLowerCase());
        }
        if (departureDate != null) {
            query.append(" and departureDate = :departureDate");
            params.put("departureDate", departureDate);
        }

        return params.isEmpty() ? listAll() : find(query.toString(), params).list();
    }
}

