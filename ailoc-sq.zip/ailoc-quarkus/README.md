# LO AI Sandbox Application

This project implements a Retrieval-Augmented Generation (RAG) solution using Spring AI, Quarkus, PostgreSQL with the `pgvector` extension, and a custom `Assistant` component. The application allows users to add textual documents to a vector store and then query the RAG system to generate enhanced responses based on the stored information.

## Features

*   **Document Ingestion**: Add textual documents to the `pgvector` store.
*   **Contextual Question Answering**: Query the RAG system, which retrieves relevant documents and augments the prompt for the AI model to provide more informed answers.
*   **Spring AI Integration**: Leverages Spring AI for seamless integration with large language models and vector store functionalities.
*   **PostgreSQL with pgvector**: Uses PostgreSQL as the database with the `pgvector` extension for efficient similarity searches on vector embeddings.

## Prerequisites

Before running this application, ensure you have the following installed:

*   **Java Development Kit (JDK)**: Version 24.
*   **Apache Maven**: Apache Maven 3.9.9 for building and managing the project.
*   **PostgreSQL**: Version 16 or higher.
*   **Docker (Optional but Recommended)**: For easily running PostgreSQL with Testcontainers during development/testing.

## Setup

1.  **Clone the Repository**:
    ```bash
    git clone <repository-url>
    cd ailoc
    ```

2.  **Database Setup**:
    This project uses PostgreSQL with the `pgvector` extension. You can set up your database manually or use Docker with Testcontainers (recommended for development).

    **a) Manual PostgreSQL Setup:**
    *   Install PostgreSQL.
    *   Connect to your PostgreSQL instance and create a database (e.g., `rag_database`) and a user (e.g., `raguser`) with a password (e.g., `ragpassword`).
    *   Enable the `pgvector` extension:
        ```sql
        CREATE EXTENSION IF NOT EXISTS vector;
        CREATE EXTENSION IF NOT EXISTS hstore;
        CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
    
        CREATE TABLE IF NOT EXISTS vector_store (
         id uuid DEFAULT uuid_generate_v4() PRIMARY KEY,
         content text,
         metadata json,
         embedding vector(1536)
        );
    
        CREATE INDEX ON vector_store USING HNSW (embedding vector_cosine_ops);
        ```
    *   The application will automatically create the `documents` table on startup if `spring.ai.vectorstore.pgvector.initialize-schema=true` is set in `application.properties`.

    **b) Using Docker with Testcontainers (Recommended):**
    The `TestcontainersConfiguration.java` in the `src/test/java` directory is set up to use Testcontainers for a PostgreSQL database with `pgvector` enabled during tests. For development, you can adapt this or simply start a PostgreSQL container manually:
    ```bash
    docker run --name some-postgres -e POSTGRES_PASSWORD=ragpassword -e POSTGRES_USER=raguser -e POSTGRES_DB=rag_database -p 5432:5432 -d pgvector/pgvector:0.8.0-pg17
    ```

3.  **Spring Application Configuration**:
    Open `src/main/resources/application.yml` and configure your database connection and Spring AI settings. Ensure the `YOUR_API_KEY` placeholder is replaced with your actual API key.
 
4. **Quarkus Application Configuration**:
    Open `src/main/resources/application.yml` and configure your database connection and Quarkus AI settings. Ensure the `YOUR_API_KEY` placeholder is replaced with your actual API key.


---

## Docker Compose Setup

You can run the entire stack (spring, quarkus, frontend, and Postgres with pgvector) using Docker Compose. This is the recommended way for local development and testing.

1.  **Environment Variable Setup (.env)**:

    You can securely provide your API key and other secrets using a `.env` file in the project root. This file is automatically read by Docker Compose.

    **Create a file named `.env` in the project root with the following content:**
    ```env
    YOUR_API_KEY={your-api-key}
    ```
    Replace `{your-api-key}` with your actual API key. This will be used by the backend service at runtime.

2. **Build and start all services:**
   ```bash
   docker-compose --profile local-ui up -d --build
   docker-compose --profile local-quarkus up -d --build
   ```
    - This will start the spring-boot-app (backend), frontend (Streamlit), and Postgres with pgvector.
    - The spring-boot-app will be available at [http://localhost:8080](http://localhost:8080)
    - The frontend will be available at [http://localhost:8501](http://localhost:8501)

3. **Stop all services:**
   ```bash
   docker-compose --profile local-ui down
   docker-compose --profile local-quarkus down
   ```

---

## Usage

You can interact with the RAG system using `curl` commands.

1.  **Add a Document**:
    To add a new document to the vector store:
    ```bash
    curl -X POST http://localhost:8080/add-text -H "Content-Type: application/json" -d "{\"content\": \"The capital of France is Paris.\", \"metadata\": {\"source\": \"manual\"}}"
    ```

2.  **Ask the Assistant**:
    To query the RAG system:
    ```bash
    curl -X POST http://localhost:8080/ask -H "Content-Type: application/json" -d "{\"query\": \"What is the capital of France?\"}"
    ```

## Travel Services (Hotels, Flights, Bookings)

Search hotels:
```bash
curl -X GET "http://localhost:8080/travel/hotels?city=Budapest&minRating=4.0" \
  -H "Accept: application/json"
```

Search flights:
```bash
curl -X GET "http://localhost:8080/travel/flights?departure=New%20York&arrival=Budapest" \
  -H "Accept: application/json"
```

Create a booking (link hotel + flight):
```bash
curl -X POST http://localhost:8080/travel/bookings \
  -H "Content-Type: application/json" \
  -d '{
    "hotelId": 1,
    "flightId": 1,
    "travelerName": "Ada Lovelace",
    "travelerEmail": "ada@example.com",
    "tripName": "Business Trip",
    "checkInDate": "2025-02-01",
    "checkOutDate": "2025-02-05",
    "status": "NEW"
  }'
```
## Travel assistant
You can ask travel-related questions to the assistant:
```bash
curl -X POST http://localhost:8080/travel/assistant \
  -H "Content-Type: application/json" \
  -d '{"query": "I want to travel to Budapest"}'
```

## Travel assistant
You can ask travel-related questions to the assistant:
Step 1: Search for hotels and flights

```bash
curl -X POST http://localhost:8080/travel/assistant \
-H "Content-Type: application/json" \
-d '{"query":"Hello currently I am in Frankfurt, and I want to travel to Budapest on 2025-12-25. Taxi to airport is 100 euro, from Frankfurt airport to Budapest is 200 eur. What is the total amount that I have to spend on this travel?  What is the Hotel name where I will be sleeping?  What is the flight that I will use for this trip ?","conversationId": "user-123"}'
```
Step 2: Specify travel details

```bash
curl -X POST http://localhost:8080/travel/assistant \
-H "Content-Type: application/json" \
-d '{"query":"departure date is 2025-12-24 from Frankfurt and I will travel alone, any hotel is good for me","conversationId": "user-123"}'
```

Step 3: Proceed to booking hotel
```bash
curl -X POST http://localhost:8080/travel/assistant \
-H "Content-Type: application/json" \
-d '{"query":"proceed booking hotel the rest I will manage","conversationId": "user-123"}'
```

## File Upload Module

This project now includes a file upload module that allows users to upload a file and store its content in the PGVector vector store.

### Endpoint
- `POST /add-document`
    - Accepts a file upload (multipart/form-data, parameter name: `file`).
    - Stores the file content as a document in PGVector, with the filename as metadata.

#### Example using `curl`:
```bash
    curl -F "file=@/path/to/your/file.txt" http://localhost:8080/add-document
```

#### Response
- `200 OK` if the file was uploaded and stored successfully.
- `400 Bad Request` if there was an error reading the file.

## Troubleshooting

*   **`pgvector` extension not found**: Make sure you have enabled the `pgvector` extension in your PostgreSQL database using `CREATE EXTENSION IF NOT EXISTS vector;`.
