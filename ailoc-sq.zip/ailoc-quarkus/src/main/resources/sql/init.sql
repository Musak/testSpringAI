-- Create extension for vector data type
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS hstore;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
-- Create table for storing vector embeddings
CREATE TABLE public.vector_store (
	embedding_id uuid NOT NULL,
	embedding vector(768) NOT NULL,
	"text" text NULL,
	metadata json NULL,
	CONSTRAINT vector_store_pkey PRIMARY KEY (embedding_id)
);
CREATE INDEX ON vector_store USING HNSW (embedding vector_cosine_ops);