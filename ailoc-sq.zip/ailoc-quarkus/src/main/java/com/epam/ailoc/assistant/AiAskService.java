package com.epam.ailoc.assistant;

import jakarta.enterprise.context.ApplicationScoped;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import io.quarkiverse.langchain4j.RegisterAiService;

@RegisterAiService(modelName = "tar")
@SystemMessage("You are an AI assistant. Use only the information provided in the context below to answer the user's question. \n" +
        "Do not use any prior knowledge or make assumptions.\n" +
        "Instructions:\n" +
        "- If the answer is not present in the context, respond with:" +
        " \"I'm sorry, I don't have the information you are looking for.\"\n" +
        "- Base your answer strictly on the context. " +
        "- Do not generate or infer information not found in the context.")
@ApplicationScoped
public interface AiAskService {

    @UserMessage("""
                Context: {context}
                Question: {question}
            """)
    String ask(String context, String question);
}