package com.epam.ailoc.assistant;

import java.util.HashMap;
import java.util.Map;

import org.jboss.logging.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/travel/assistant")
public class TravelAssistantResource {

    private static final Logger LOG = Logger.getLogger(TravelAssistantResource.class);

    private final TravelAgent travelAgent;

    // Reusable ObjectMapper for JSON parsing
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    public TravelAssistantResource(TravelAgent travelAgent) {
        this.travelAgent = travelAgent;
    }

    @POST
    @Consumes({MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
    @Produces(MediaType.APPLICATION_JSON)
    public Response chat(String rawMessage) {
        if (rawMessage == null || rawMessage.isBlank()) {
            LOG.warn("Received null or empty request");
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Request cannot be null or empty");
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity(errorResponse)
                    .build();
        }

        String message = rawMessage;

        LOG.infof("Received travel assistant request: %s", message);

        try {
            // travelAgent.chat(message) returns a stream (Multi<String>) of chat chunks.
            // Collect all chunks into a single string
            String fullResponse = travelAgent.chat(message)
                    .collect()
                    .asList()
                    .await()
                    .indefinitely()
                    .stream()
                    .reduce("", (acc, chunk) -> acc + chunk);

            // Return as JSON to match WebSocket format
            Map<String, String> responseMap = new HashMap<>();
            responseMap.put("answer", fullResponse);

            LOG.infof("Travel assistant response generated successfully");
            return Response.ok(responseMap).build();

        } catch (Exception e) {
            LOG.errorf("Error processing travel assistant request: %s", e.getMessage(), e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Failed to process request: " + e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity(errorResponse)
                    .build();
        }
    }
}

