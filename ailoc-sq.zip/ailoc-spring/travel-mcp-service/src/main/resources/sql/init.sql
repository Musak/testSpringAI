-- 1. Clean up old tables (CASCADE removes the bookings table automatically)
DROP TABLE IF EXISTS hotels CASCADE;
DROP TABLE IF EXISTS flights CASCADE;
DROP TABLE IF EXISTS bookings CASCADE;

-- 2. Create Tables with correct constraints
CREATE TABLE hotels (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    city VARCHAR(128) NOT NULL,
    country VARCHAR(128) NOT NULL,
    price_per_night NUMERIC(12,2),
    rating DOUBLE PRECISION,
    -- This constraint is required for "ON CONFLICT (name, city)" to work
    CONSTRAINT uq_hotels_name_city UNIQUE (name, city)
);

CREATE TABLE flights (
    id BIGSERIAL PRIMARY KEY,
    airline VARCHAR(128) NOT NULL,
    -- This UNIQUE constraint is required for "ON CONFLICT (flight_number)" to work
    flight_number VARCHAR(64) NOT NULL UNIQUE,
    departure VARCHAR(128) NOT NULL,
    arrival VARCHAR(128) NOT NULL,
    departure_date DATE NOT NULL,
    departure_time TIME,
    arrival_time TIME,
    price NUMERIC(12,2)
);

CREATE TABLE bookings (
    id BIGSERIAL PRIMARY KEY,
    hotel_id BIGINT REFERENCES hotels(id),
    flight_id BIGINT REFERENCES flights(id),
    traveler_name VARCHAR(255) NOT NULL,
    traveler_email VARCHAR(255),
    trip_name VARCHAR(255),
    check_in DATE,
    check_out DATE,
    status VARCHAR(64),
    total_price NUMERIC(12,2),
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 3. Seed data
-- Note: Fixed the double quotes in INTERVAL (use '7 days', not ''7 day'')
INSERT INTO hotels (name, city, country, price_per_night, rating) VALUES
    ('Central Park Hotel', 'New York', 'USA', 220.00, 4.4),
    ('Danube Riverside', 'Budapest', 'Hungary', 140.00, 4.6),
    ('Shinjuku Stay', 'Tokyo', 'Japan', 180.00, 4.5)
ON CONFLICT (name, city) DO NOTHING;

INSERT INTO flights (airline, flight_number, departure, arrival, departure_date, departure_time, arrival_time, price) VALUES
    ('SkyWays', 'SW123', 'New York', 'Budapest', CURRENT_DATE + INTERVAL '7 days', '09:00', '23:30', 750.00),
    ('EuroAir', 'EU123', 'Frankfurt', 'Budapest', CURRENT_DATE + INTERVAL '7 days', '10:00', '23:30', 750.00),
    ('EuroAir', 'EA456', 'Budapest', 'Tokyo', CURRENT_DATE + INTERVAL '14 days', '12:15', '22:55', 680.00),
    ('Pacific', 'PC789', 'Tokyo', 'New York', CURRENT_DATE + INTERVAL '21 days', '08:45', '19:10', 910.00)
ON CONFLICT (flight_number) DO NOTHING;