package com.epam.ailoc.travelmcp.travel;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.epam.ailoc.travelmcp.travel.model.Hotel;
import com.epam.ailoc.travelmcp.travel.repository.HotelRepository;

@RestController
@RequestMapping("/travel/hotels")
public class HotelController {

    private final HotelRepository hotelRepository;

    public HotelController(HotelRepository hotelRepository
    ) {
        this.hotelRepository = hotelRepository;
    }

    @GetMapping
    public List<Hotel> searchHotels(
            @RequestParam(required = false) String city,
            @RequestParam(required = false) String country,
            @RequestParam(required = false) Double minRating) {
        return hotelRepository.search(city, country, minRating);
    }
}

