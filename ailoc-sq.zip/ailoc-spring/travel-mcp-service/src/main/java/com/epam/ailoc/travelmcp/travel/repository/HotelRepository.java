package com.epam.ailoc.travelmcp.travel.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.epam.ailoc.travelmcp.travel.model.Hotel;

@Repository
public interface HotelRepository extends JpaRepository<Hotel, Long> {

    @Query(value = "SELECT * FROM hotels h WHERE " +
           "(CASE WHEN :city IS NULL THEN TRUE ELSE LOWER(h.city) = LOWER(CAST(:city AS VARCHAR)) END) AND " +
           "(CASE WHEN :country IS NULL THEN TRUE ELSE LOWER(h.country) = LOWER(CAST(:country AS VARCHAR)) END) AND " +
           "(:minRating IS NULL OR h.rating >= :minRating)", 
           nativeQuery = true)
    List<Hotel> search(@Param("city") String city, 
                       @Param("country") String country, 
                       @Param("minRating") Double minRating);
}

