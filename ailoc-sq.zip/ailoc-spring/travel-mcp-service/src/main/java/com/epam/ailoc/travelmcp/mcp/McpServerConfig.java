package com.epam.ailoc.travelmcp.mcp;

import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * MCP server configuration.
 * Exposes MCP tools by scanning for @Tool annotated methods in registered services.
 */
@Configuration
public class McpServerConfig {
    /**
     * Expose annotated tool methods to the MCP server.
     * The MCP services (HotelMcpService, FlightMcpService, BookingMcpService) contain
     * the travel-related tools, keeping MCP configuration separate from the REST controllers.
     */
    @Bean
    public ToolCallbackProvider mcpTools(
            HotelMcpService hotelMcpService,
            FlightMcpService flightMcpService,
            BookingMcpService bookingMcpService) {
        return MethodToolCallbackProvider.builder()
                .toolObjects(hotelMcpService, flightMcpService, bookingMcpService)
                .build();
    }
}

