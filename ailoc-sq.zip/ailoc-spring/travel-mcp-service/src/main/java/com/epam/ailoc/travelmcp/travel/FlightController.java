package com.epam.ailoc.travelmcp.travel;

import java.time.LocalDate;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.epam.ailoc.travelmcp.travel.model.Flight;
import com.epam.ailoc.travelmcp.travel.repository.FlightRepository;

@RestController
@RequestMapping("/travel/flights")
public class FlightController {

    private final FlightRepository flightRepository;

    public FlightController(FlightRepository flightRepository) {
        this.flightRepository = flightRepository;
    }

    @GetMapping
    public List<Flight> searchFlights(
            @RequestParam(required = false) String departure,
            @RequestParam(required = false) String arrival,
            @RequestParam(required = false) LocalDate departureDate) {
        return flightRepository.search(departure, arrival, departureDate);
    }
}

