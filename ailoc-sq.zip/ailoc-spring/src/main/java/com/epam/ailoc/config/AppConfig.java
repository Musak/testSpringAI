package com.epam.ailoc.config;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.memory.MessageWindowChatMemory;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.boot.web.client.RestClientCustomizer;
import org.springframework.boot.web.reactive.function.client.WebClientCustomizer;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;

import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.Optional;

import static org.slf4j.LoggerFactory.getLogger;

@Configuration
public class AppConfig {

    @Value("${spring.ai.vectorstore.pgvector.table-name:documents}")
    private String tableName;

    @Value("${spring.ai.vectorstore.pgvector.schema-name:public}")
    private String schemaName;

    @Value("${spring.ai.openai.api-key:}")
    private String apiKey;

    @Bean
    public ChatMemory chatMemory() {
        return MessageWindowChatMemory.builder()
                .maxMessages(20) // Keep last 20 messages in memory
                .build();
    }

    @Bean
    public ChatClient chatClient(ChatModel chatModel, ChatMemory chatMemory) {
        return ChatClient.builder(chatModel)
                .defaultAdvisors(MessageChatMemoryAdvisor.builder(chatMemory).build())
                .build();
    }

    //Requires to override the default RestClient to add custom headers for PGVectors and Embeddings related requests
    @Bean
    public ClientHttpRequestInterceptor apiKeyHeaderInterceptor() {
        return (request, body, execution) -> {
            request.getHeaders().set("API-KEY", apiKey);
            request.getHeaders().remove("Authorization");
            return execution.execute(request, body);
        };
    }

    @Bean
    public RestClientCustomizer restClientCustomizer(ClientHttpRequestInterceptor apiKeyHeaderInterceptor) {
        return restClientBuilder -> restClientBuilder.requestInterceptor(apiKeyHeaderInterceptor);
    }

    // Interceptor to log outgoing HTTP requests/responses for RestClient
    @Bean
    public ClientHttpRequestInterceptor loggingInterceptor() {
        return (request, body, execution) -> {
            long start = System.currentTimeMillis();
            String uri = request.getURI().toString();
            String method = request.getMethod() == null ? "" : request.getMethod().name();
            String requestBody = body == null ? "" : new String(body, StandardCharsets.UTF_8);
            org.slf4j.Logger logger = getLogger("http-client-outgoing");
            logger.debug("Outgoing request: {} {} body={}", method, uri, requestBody);
            var response = execution.execute(request, body);
            long took = System.currentTimeMillis() - start;
            String responseBody = "<non-buffered>";
            logger.debug("Incoming response: {} {} status={} took={}ms body={}", method, uri, response.getStatusCode(), took, responseBody);
            return response;
        };
    }

    // Register loggingInterceptor for RestClient as well
    @Bean
    public RestClientCustomizer loggingRestClientCustomizer(ClientHttpRequestInterceptor loggingInterceptor) {
        return restClientBuilder -> restClientBuilder.requestInterceptor(loggingInterceptor);
    }

    // Reactive filter to add Authorization header for WebClient requests
    @Bean
    public ExchangeFilterFunction authorizationFilter() {
        return ExchangeFilterFunction.ofRequestProcessor(clientRequest -> {
            if (apiKey == null || apiKey.isBlank()) {
                return Mono.just(clientRequest);
            }
            ClientRequest newRequest = ClientRequest.from(clientRequest)
                    .headers(h -> h.add("API-KEY", apiKey))
                    .headers(h -> h.remove("Authorization"))
                    .build();
            return Mono.just(newRequest);
        });
    }

    // WebClient customizer to add exchange filter to log request/response
    @Bean
    public WebClientCustomizer webClientCustomizer(ExchangeFilterFunction authorizationFilter) {
        return webClientBuilder -> {
            ExchangeFilterFunction logFilter = ExchangeFilterFunction.ofRequestProcessor(clientRequest -> {
                org.slf4j.Logger logger = getLogger("webclient-outgoing");
                Optional<Object> attr = clientRequest.attribute("request-body");
                String requestBody = attr.map(Object::toString).orElse("<non-buffered>");

                logger.info("WebClient request -> method={} url={} headers={} body={}",
                        clientRequest.method(), clientRequest.url(), clientRequest.headers(), requestBody);
                return Mono.just(clientRequest);
            }).andThen(ExchangeFilterFunction.ofResponseProcessor(clientResponse -> {
                org.slf4j.Logger logger = getLogger("webclient-outgoing");
                return clientResponse.bodyToMono(String.class)
                        .defaultIfEmpty("")
                        .flatMap(body -> {
                            logger.info("WebClient response -> status={} headers={} body={}",
                                    clientResponse.statusCode(), clientResponse.headers().asHttpHeaders(), body);
                            ClientResponse newResponse = ClientResponse.from(clientResponse).body(body).build();
                            return Mono.just(newResponse);
                        });
            }));

            webClientBuilder.filters(filters -> {
                // Ensure authorization header is applied before other filters
                filters.add(0, authorizationFilter);
                filters.add(logFilter);
            });
        };
    }
}