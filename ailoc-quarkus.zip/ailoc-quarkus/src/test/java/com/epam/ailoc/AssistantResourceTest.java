package com.epam.ailoc;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
class AssistantResourceTest {

    @Test
    void testAddTextDocument() {
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("source", "test");
        metadata.put("document_id", "1");
        
        Map<String, Object> request = new HashMap<>();
        request.put("content", "The capital of France is Paris.");
        request.put("metadata", metadata);

        given()
          .contentType(ContentType.JSON)
          .body(request)
          .when().post("/add-text")
          .then()
             .statusCode(200)
             .body(is("Document added successfully!"));
    }

    @Test
    void testAddTextDocumentWithoutMetadata() {
        Map<String, Object> request = new HashMap<>();
        request.put("content", "Java is a programming language.");

        given()
          .contentType(ContentType.JSON)
          .body(request)
          .when().post("/add-text")
          .then()
             .statusCode(200)
             .body(is("Document added successfully!"));
    }

    @Test
    void testAskEndpoint() {
        // First, add a document
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("source", "test");
        
        Map<String, Object> addRequest = new HashMap<>();
        addRequest.put("content", "Quarkus is a Kubernetes-native Java framework.");
        addRequest.put("metadata", metadata);

        given()
          .contentType(ContentType.JSON)
          .body(addRequest)
          .when().post("/add-text")
          .then()
             .statusCode(200);

        // Then ask a question
        Map<String, String> askRequest = new HashMap<>();
        askRequest.put("query", "What is Quarkus?");

        given()
          .contentType(ContentType.JSON)
          .body(askRequest)
          .when().post("/ask")
          .then()
             .statusCode(200)
             .body("answer", notNullValue());
    }

    @Test
    void testAskEndpointWithEmptyQuery() {
        Map<String, String> askRequest = new HashMap<>();
        askRequest.put("query", "");

        given()
          .contentType(ContentType.JSON)
          .body(askRequest)
          .when().post("/ask")
          .then()
             .statusCode(200);
    }

}

