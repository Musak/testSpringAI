package com.epam.ailoc;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.is;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;

@QuarkusTest
class FileUploadResourceTest {

    @Test
    void testFileUpload() throws IOException {
        Path tempFile = Files.createTempFile("test", ".txt");
        Files.write(tempFile, "This is a test document content.".getBytes());

        try {
            given()
              .multiPart("file", tempFile.toFile())
              .when().post("/add-document")
              .then()
                 .statusCode(200)
                 .body(is("File uploaded and content stored successfully!"));
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    void testFileUploadWithMissingFile() {
        given()
          .when().post("/add-document")
          .then()
             .statusCode(400);
    }

}
