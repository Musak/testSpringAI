package com.epam.ailoc.assistant;

import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.guardrail.InputGuardrail;
import dev.langchain4j.guardrail.InputGuardrailResult;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class PromptInjectionGuard implements InputGuardrail {

    private final PromptInjectionDetectionService service;

    @Inject
    public PromptInjectionGuard(PromptInjectionDetectionService service) {
        this.service = service;
    }

    @Override
    public InputGuardrailResult validate(UserMessage userMessage) {
        double result = service.isInjection(userMessage.singleText());
        if (result > 0.7) {
            return failure("Prompt injection detected. Your request contains potentially malicious content and cannot be processed.");
        }
        return success();
    }
}

