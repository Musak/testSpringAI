package com.epam.ailoc.assistant;

import java.util.HashMap;
import java.util.Map;

import org.jboss.logging.Logger;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import dev.langchain4j.guardrail.InputGuardrailException;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/travel/assistant")
public class TravelAssistantResource {

    private static final Logger LOG = Logger.getLogger(TravelAssistantResource.class);

    private final TravelAgentRest travelAgent;

    @Inject
    public TravelAssistantResource(TravelAgentRest travelAgent) {
        this.travelAgent = travelAgent;
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response chat(TravelAssistantRequest request) {
        if (request == null) {
            LOG.warn("Received null request");
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Request cannot be null");
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity(errorResponse)
                    .build();
        }

        // Validate required fields
        if (request.conversationId == null || request.conversationId.isBlank()) {
            LOG.warn("Received request with missing or empty conversationId");
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "conversationId is required and cannot be empty");
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity(errorResponse)
                    .build();
        }

        if (request.query == null || request.query.isBlank()) {
            LOG.warn("Received request with missing or empty query");
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "query is required and cannot be empty");
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity(errorResponse)
                    .build();
        }

        LOG.infof("Received travel assistant request with conversationId=%s: %s", request.conversationId, request.query);

        try {
            // Pass memoryId to enable conversation memory
            String fullResponse = travelAgent.chat(request.conversationId, request.query);

            // Return as JSON to match WebSocket format
            Map<String, String> responseMap = new HashMap<>();
            responseMap.put("answer", fullResponse);
            responseMap.put("conversationId", request.conversationId);

            LOG.infof("Travel assistant response generated successfully for conversationId=%s", request.conversationId);
            return Response.ok(responseMap).build();

        } catch (InputGuardrailException e) {
            LOG.errorf(e, "Prompt injection detected: %s", e.getMessage());
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Sorry, I am unable to process your request. It contains potentially malicious content.");
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity(errorResponse)
                    .build();
        } catch (Exception e) {
            LOG.errorf("Error processing travel assistant request: %s", e.getMessage(), e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "I ran into some problems. Please try again.");
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity(errorResponse)
                    .build();
        }
    }

    /**
     * Request DTO for travel assistant chat endpoint.
     * conversationId is required to maintain conversation memory.
     */
    public static class TravelAssistantRequest {
        
        @JsonProperty("conversationId")
        public final String conversationId;
        
        @JsonProperty("query")
        public final String query;

        @JsonCreator
        public TravelAssistantRequest(
                @JsonProperty("conversationId") String conversationId,
                @JsonProperty("query") String query) {
            this.conversationId = conversationId;
            this.query = query;
        }
    }
}

