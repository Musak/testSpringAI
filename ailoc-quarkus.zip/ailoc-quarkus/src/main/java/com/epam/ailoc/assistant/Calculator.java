package com.epam.ailoc.assistant;

import dev.langchain4j.agent.tool.Tool;
import jakarta.enterprise.context.ApplicationScoped;
import org.jboss.logging.Logger;

@ApplicationScoped
public class Calculator {

    private static final Logger LOG = Logger.getLogger(TravelWebSocket.class);

    @Tool(
            name = "add",
            value = "Add two integers and return their sum. Signature: add(a: int, b: int) -> int."
    )
    public Integer add(int a, int b) {

        LOG.infof("Received websocket message: %s + %s ", a, b);
        return a + b;
    }

    @Tool(
            name = "subtract",
            value = "Subtract second integer from first and return the result. Signature: subtract(a: int, b: int) -> int."
    )
    public Integer subtract(int a, int b) {
        LOG.infof("Received websocket message: %s - %s ", a, b);
        return a - b;
    }

    @Tool(
            name = "multiply",
            value = "Multiply two integers and return the product. Signature: multiply(a: int, b: int) -> int."
    )
    public Integer multiply(int a, int b) {
        LOG.infof("Received websocket message: %s * %s ", a,b);
        return a * b;
    }

    @Tool(
            name = "divide",
            value = "Divide first integer by second and return integer quotient. Throws IllegalArgumentException on division by zero. Signature: divide(a: int, b: int) -> int."
    )
    public Integer divide(int a, int b) {
        LOG.infof("Received websocket message: %s / %s ", a,b);
        if (b == 0) {
            throw new IllegalArgumentException("Division by zero is not allowed.");
        }
        return a / b;
    }
}
