package com.epam.ailoc.config;

import jakarta.annotation.Priority;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.client.ClientRequestContext;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.ext.Provider;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import java.io.IOException;

/**
 * Configuration class for the application.
 * 
 *
 * If you need custom configuration like apikey, you can override the auto-configured beans here.
 */
@Provider
@ApplicationScoped
@Priority(Priorities.AUTHENTICATION)
public class RestClientHeaderFilter implements ClientRequestFilter {

    @Inject
    @ConfigProperty(name = "quarkus.langchain4j.openai.api-key", defaultValue = "DIAL API KEY HERE")
    String apiKey;


    @Override
    public void filter(ClientRequestContext requestContext) throws IOException {
         requestContext.getHeaders().putSingle("API-KEY", apiKey);
         System.out.println("Auth from config: " + requestContext.getHeaders().get("Authorization"));
        // requestContext.getHeaders().putSingle("API-KEY", "Bearer ");
         requestContext.getHeaders().remove("Authorization");
    }
}
