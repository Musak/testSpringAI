package com.epam.ailoc.assistant;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import io.quarkiverse.langchain4j.ModelName;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import dev.langchain4j.data.document.Metadata;
import dev.langchain4j.data.embedding.Embedding;
import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.model.chat.ChatModel;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.store.embedding.EmbeddingMatch;
import dev.langchain4j.store.embedding.EmbeddingSearchRequest;
import dev.langchain4j.store.embedding.EmbeddingSearchResult;
import dev.langchain4j.store.embedding.EmbeddingStore;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.jboss.logging.Logger;

@Path("/")
public class Assistant {

    private static final Logger LOGGER = Logger.getLogger(Assistant.class);

    @Inject
    ChatModel chatModel;

    @Inject
    AiAskService aiAskService;

    @Inject
    EmbeddingStore<TextSegment> embeddingStore;

    @Inject
    @ModelName("foo")
    EmbeddingModel embeddingModel;

    @Inject
    @ModelName("bar")
    EmbeddingModel embeddingBarModel;

    @ConfigProperty(name = "app.similarity.top-k", defaultValue = "3")
    Integer topK;

    @ConfigProperty(name = "app.similarity.threshold", defaultValue = "0.2")
    Double similarityThreshold;

    @POST
    @Path("/add-text")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.TEXT_PLAIN)
    public Response addDocument(AddDocumentRequest request) {
        LOGGER.info("addDocument called; metadata keys: " + request.metadata() != null ? request.metadata().keySet() : "none");
        try {
            // Create metadata
            Metadata metadata = new Metadata();
            if (request.metadata() != null) {
                request.metadata().forEach((key, value) -> {
                    if (value != null) {
                        metadata.put(key, value.toString());
                    }
                });
            }

            // Create TextSegment with content and metadata
            TextSegment segment = TextSegment.from(request.content(), metadata);
            dev.langchain4j.model.output.Response<Embedding> embed = embeddingModel.embed(segment);
            dev.langchain4j.model.output.Response<Embedding> embedBar = embeddingBarModel.embed(segment);


            // Generate embedding
            Embedding embedding = embed.content();
            Map<String, Object> responseMeta = embed.metadata();
            LOGGER.info("Generated embedding for document of length "+ embed.content().dimension());
            LOGGER.info("Embedding metadata: " + responseMeta);
            LOGGER.info("Embedding: " + embedding);

            // Store in embedding store
            embeddingStore.add(embedding, segment);
            LOGGER.info("Document added to embedding store successfully");

            // second embedding with different model
            LOGGER.info("Generated second embedding for document of length "+ embedBar.content().dimension());
            embeddingStore.add(embedBar.content(), segment);


            return Response.ok("Document added successfully!").build();
        } catch (Exception e) {
            LOGGER.error("Failed to add document", e);
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("Failed to add document: " + e.getMessage())
                    .build();
        }
    }

    @POST
    @Path("/ask")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response askAssistant(AskAssistantRequest request) {
        LOGGER.info("askAssistant called with query: "+ request.query());
        try {
            // Generate embedding for the query
            Embedding queryEmbedding = embeddingModel.embed(request.query()).content();

            // Search for similar documents
            EmbeddingSearchRequest searchRequest = EmbeddingSearchRequest.builder()
                    .queryEmbedding(queryEmbedding)
                    .maxResults(topK)
                    .minScore(1.0 - similarityThreshold) // Convert similarity threshold to min score
                    .build();

            EmbeddingSearchResult<TextSegment> searchResult = embeddingStore.search(searchRequest);

            int matchCount = searchResult.matches() != null ? searchResult.matches().size() : 0;
            LOGGER.debug("Embedding search returned matches: "+ matchCount);

            // Extract document content
            String documentContent = searchResult.matches().stream()
                    .map(EmbeddingMatch::embedded)
                    .map(TextSegment::text)
                    .collect(Collectors.joining("\n"));

            String response = aiAskService.ask(documentContent, request.query());
            LOGGER.info("AI response generated for query");

            // Return as JSON to match UI expectations
            Map<String, String> responseMap = new HashMap<>();
            responseMap.put("answer", response);

            return Response.ok(responseMap).build();
        } catch (Exception e) {
            LOGGER.error("Error processing request", e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Error processing request: " + e.getMessage())
                    .build();
        }
    }

    public record AddDocumentRequest(String content, Map<String, Object> metadata) {}

    public record AskAssistantRequest(String query) {}
}
