package com.epam.ailoc.assistant;

import dev.langchain4j.guardrail.InputGuardrailException;
import io.quarkus.websockets.next.OnOpen;
import io.quarkus.websockets.next.OnTextMessage;
import io.quarkus.websockets.next.WebSocket;
import io.smallrye.mutiny.Multi;
import jakarta.inject.Inject;

import org.jboss.logging.Logger;

import java.util.HashMap;
import java.util.Map;

// Add Jackson import
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;

@WebSocket(path="/travel")
public class TravelWebSocket {

    private static final Logger LOG = Logger.getLogger(TravelWebSocket.class);

    private final TravelAgent travelAgent;

    // Reusable ObjectMapper for optional JSON parsing
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    public TravelWebSocket(TravelAgent travelAgent) {
        this.travelAgent = travelAgent;
    }

    @OnOpen
    public void onOpen() {
        LOG.info("WebSocket connection established for /travel");
    }

    // Accept raw text and try to parse JSON into Assistant.AskAssistantRequest.
    // If parsing fails (e.g. incoming message is plain text like "Hello"), use the raw string as the query.
    @OnTextMessage
    public Multi<Map<String, String>> onTextMessage(String rawMessage) {
        if (rawMessage == null) {
            LOG.warn("Received null websocket message");
            return Multi.createFrom().empty();
        }

        String message = rawMessage;

        // Try to parse JSON payload into Assistant.AskAssistantRequest if possible
        try {
            // Trim to quickly check if it *looks* like JSON to avoid expensive parsing attempts
            String trimmed = rawMessage.trim();
            if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
                try {
                    Assistant.AskAssistantRequest req = MAPPER.readValue(trimmed, Assistant.AskAssistantRequest.class);
                    if (req != null && req.query() != null) {
                        message = req.query();
                    }
                } catch (JsonProcessingException e) {
                    // Not JSON we expect, fall back to raw text
                    LOG.debugf("Failed to parse websocket JSON payload, using raw text. Error: %s", e.getMessage());
                }
            }
        } catch (Exception e) {
            // Defensive: any unexpected errors while parsing shouldn't break the websocket
            LOG.debugf("Unexpected error while parsing websocket message: %s", e.getMessage());
        }

        LOG.infof("Received websocket message: %s", message);

        try {
            // travelAgent.chat(message) returns a stream (Multi<String>) of chat chunks.
            // Map each emitted String into a fresh Map so the websocket can send JSON objects.
            return travelAgent.chat(message)
                    .map(answerChunk -> {
                        Map<String, String> responseMap = new HashMap<>();
                        responseMap.put("answer", answerChunk);
                        return responseMap;
                    });
        } catch (InputGuardrailException e) {
            LOG.errorf(e, "Prompt injection detected: %s", e.getMessage());
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Sorry, I am unable to process your request. It contains potentially malicious content.");
            return Multi.createFrom().item(errorResponse);
        } catch (Exception e) {
            LOG.errorf(e, "Error calling the LLM: %s", e.getMessage());
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "I ran into some problems. Please try again.");
            return Multi.createFrom().item(errorResponse);
        }
    }
}
