package com.epam.ailoc.fileupload;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import dev.langchain4j.data.document.splitter.DocumentByLineSplitter;
import dev.langchain4j.store.embedding.EmbeddingStoreIngestor;
import org.jboss.resteasy.reactive.multipart.FileUpload;

import dev.langchain4j.data.document.Metadata;
import dev.langchain4j.data.embedding.Embedding;
import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.store.embedding.EmbeddingStore;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/add-document")
public class FileUploadController {

    @Inject
    EmbeddingStore<TextSegment> embeddingStore;

    @Inject
    EmbeddingModel embeddingModel;

    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.TEXT_PLAIN)
    public Response uploadFile(@FormParam("file") FileUpload file) {
        try {
            String content = new String(java.nio.file.Files.readAllBytes(file.uploadedFile()), StandardCharsets.UTF_8);
            // File content received

            // Create metadata
            Map<String, String> metadata = new HashMap<>();
            metadata.put("filename", file.fileName());

            // Create TextSegment with content and metadata
            Metadata langchainMetadata = new Metadata();
            metadata.forEach(langchainMetadata::put);
            TextSegment segment = TextSegment.from(content, langchainMetadata);

            // Generate embedding
            Embedding embedding = embeddingModel.embed(segment).content();

            // Store in embedding store
            embeddingStore.add(embedding, segment);

            return Response.ok("File uploaded and content stored successfully!").build();
        } catch (IOException e) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("Failed to read file: " + e.getMessage())
                    .build();
        }
    }
}
