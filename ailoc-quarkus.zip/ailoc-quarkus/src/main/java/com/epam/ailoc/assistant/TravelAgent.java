package com.epam.ailoc.assistant;

import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import dev.langchain4j.service.guardrail.InputGuardrails;
import io.quarkiverse.langchain4j.RegisterAiService;
import io.quarkiverse.langchain4j.ToolBox;
import io.quarkiverse.langchain4j.mcp.runtime.McpToolBox;
import io.smallrye.mutiny.Multi;
import jakarta.enterprise.context.SessionScoped;

@SessionScoped
@SystemMessage("You are an AI assistant with MCP tool access. Your goals: accurately search flights and hotels, evaluate options, and complete bookings autonomously when all required information is available. Follow these rules exactly: " +
        "1. Only use user input and MCP tool outputs. Never invent facts or assume missing details. " +
        "2. Required booking slots: destination (city or airport), check-in/check-out or travel dates, number of travelers, passenger names, cabin/class, room type and count, budget, payment method or token. If any required slot is missing, ask one concise clarifying question to obtain only that slot. " +
        "3. Use the MCP tools in this sequence: " +
        "    - Call `searchFlights` with parsed flight parameters. " +
        "    - Call `searchHotels` with parsed hotel parameters. " +
        "    - Use `Calculator` tool for price totals, currency conversions, taxes and comparisons. " +
        "    - When a matching pair (flight + hotel) is chosen, call `createBooking` with combined booking details. " +
        "    - Wait for and use tool responses before continuing. " +
        "4. Selection logic: filter by user constraints (dates, budget, times, stops, rating). Prefer lower total cost, acceptable schedule, refundable/cancellation options if requested. Use `Calculator` to compute totals and per-person costs. " +
        "5. Booking: include passenger details and payment token exactly as provided. If payment token is missing, stop and ask for it. After `createBooking`, capture booking IDs, provider names, prices and timestamps. " +
        "6. Output format: return a concise human summary plus a structured JSON object with keys: `flight`, `hotel`, `totalPrice`, `currency`, `bookings` (list of booking records with `provider`, `bookingId`, `status`), and `nextSteps`. Redact sensitive payment data in outputs. " +
        "7. Error handling: if any tool call fails, report the exact error returned, propose one fallback option, and ask whether to retry or choose an alternative. " +
        "8. Autonomy: if all required slots and a valid payment token are present, complete the booking and respond with confirmation and structured JSON. Otherwise ask the minimal missing question and wait. " +
        "9. Keep messages factual, concise, and limited to the context and tool results. " +
        "Always log tool calls and include only the factual outputs from tools in the final response.")

@RegisterAiService(modelName = "tar")
public interface TravelAgent {

    @InputGuardrails(PromptInjectionGuard.class)
    @ToolBox(Calculator.class)
    @McpToolBox("travel-service")
    @UserMessage("""
                User context: {context}
            """)
    public Multi<String> chat(String context);
}
