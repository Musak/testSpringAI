package com.epam.ailoc.assistant;

import io.quarkiverse.langchain4j.RegisterAiService;
import io.smallrye.mutiny.Multi;
import jakarta.enterprise.context.SessionScoped;

@SessionScoped
@RegisterAiService(modelName = "gpt-4o-mini")
public interface HelloAgent {

    Multi<String> chat(String message);
}
