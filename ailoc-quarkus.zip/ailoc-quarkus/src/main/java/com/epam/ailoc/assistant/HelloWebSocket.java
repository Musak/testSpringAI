package com.epam.ailoc.assistant;

import io.quarkus.websockets.next.OnOpen;
import io.quarkus.websockets.next.OnTextMessage;
import io.quarkus.websockets.next.WebSocket;
import io.smallrye.mutiny.Multi;
import jakarta.inject.Inject;

import org.jboss.logging.Logger;

import java.util.HashMap;
import java.util.Map;

@WebSocket(path="/hello")
public class HelloWebSocket {

    private static final Logger LOG = Logger.getLogger(HelloWebSocket.class);

    private final HelloAgent helloAgent;

    @Inject
    public HelloWebSocket(HelloAgent helloAgent) {
        this.helloAgent = helloAgent;
    }

    @OnOpen
    public void onOpen() {
        LOG.info("WebSocket connection established for /hello");
    }

    @OnTextMessage
    public Multi<Map<String, String>> onTextMessage(Assistant.AskAssistantRequest request) {
        String message = request.query();
        LOG.debugf("Received websocket message: %s", message);
        // helloAgent.chat(message) returns a stream (Multi<String>) of chat chunks.
        // Map each emitted String into a fresh Map so the websocket can send JSON objects.
        return helloAgent.chat(message)
                .map(answerChunk -> {
                    Map<String, String> responseMap = new HashMap<>();
                    responseMap.put("answer", answerChunk);
                    return responseMap;
                });
    }
}
