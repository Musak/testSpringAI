package com.epam.ailoc.travel.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

import io.quarkus.hibernate.orm.panache.PanacheEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

@Entity
@Table(name = "bookings")
public class Booking extends PanacheEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "hotel_id")
    public Hotel hotel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "flight_id")
    public Flight flight;

    @Column(name = "traveler_name", nullable = false)
    public String travelerName;

    @Column(name = "traveler_email")
    public String travelerEmail;

    @Column(name = "trip_name")
    public String tripName;

    @Column(name = "check_in")
    public LocalDate checkInDate;

    @Column(name = "check_out")
    public LocalDate checkOutDate;

    @Column(name = "status")
    public String status;

    @Column(name = "total_price")
    public BigDecimal totalPrice;

    @Column(name = "created_at", nullable = false)
    public OffsetDateTime createdAt;

    @PrePersist
    void prePersist() {
        if (createdAt == null) {
            createdAt = OffsetDateTime.now();
        }
        if (status == null) {
            status = "NEW";
        }
    }
}

