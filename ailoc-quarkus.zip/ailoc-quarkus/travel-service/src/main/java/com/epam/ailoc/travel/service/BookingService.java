package com.epam.ailoc.travel.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import com.epam.ailoc.travel.model.Booking;
import com.epam.ailoc.travel.model.Flight;
import com.epam.ailoc.travel.model.Hotel;
import com.epam.ailoc.travel.repository.BookingRepository;
import com.epam.ailoc.travel.repository.FlightRepository;
import com.epam.ailoc.travel.repository.HotelRepository;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;

@ApplicationScoped
public class BookingService {

    @Inject
    BookingRepository bookingRepository;

    @Inject
    HotelRepository hotelRepository;

    @Inject
    FlightRepository flightRepository;

    @Transactional
    public Booking createBooking(CreateBookingRequest request) {
        if (request == null) {
            throw new IllegalArgumentException("Booking request cannot be null");
        }
        if (request.travelerName() == null || request.travelerName().isBlank()) {
            throw new IllegalArgumentException("Traveler name is required");
        }

        Hotel hotel = null;
        if (request.hotelId() != null) {
            hotel = hotelRepository.findById(request.hotelId());
            if (hotel == null) {
                throw new NotFoundException("Hotel not found for id: " + request.hotelId());
            }
        }

        Flight flight = null;
        if (request.flightId() != null) {
            flight = flightRepository.findById(request.flightId());
            if (flight == null) {
                throw new NotFoundException("Flight not found for id: " + request.flightId());
            }
        }

        Booking booking = new Booking();
        booking.hotel = hotel;
        booking.flight = flight;
        booking.travelerName = request.travelerName();
        booking.travelerEmail = request.travelerEmail();
        booking.tripName = request.tripName();
        booking.checkInDate = request.checkInDate();
        booking.checkOutDate = request.checkOutDate();
        booking.status = request.status();
        booking.totalPrice = calculateTotalPrice(hotel, flight, request.checkInDate(), request.checkOutDate());

        bookingRepository.persist(booking);
        return booking;
    }

    private BigDecimal calculateTotalPrice(Hotel hotel, Flight flight, LocalDate checkIn, LocalDate checkOut) {
        BigDecimal total = BigDecimal.ZERO;

        if (hotel != null && hotel.pricePerNight != null && checkIn != null && checkOut != null) {
            long nights = ChronoUnit.DAYS.between(checkIn, checkOut);
            if (nights < 0) {
                throw new IllegalArgumentException("checkOutDate must be after checkInDate");
            }
            total = total.add(hotel.pricePerNight.multiply(BigDecimal.valueOf(Math.max(nights, 0))));
        }

        if (flight != null && flight.price != null) {
            total = total.add(flight.price);
        }

        return total.compareTo(BigDecimal.ZERO) > 0 ? total : null;
    }

    public record CreateBookingRequest(
            Long hotelId,
            Long flightId,
            String travelerName,
            String travelerEmail,
            String tripName,
            LocalDate checkInDate,
            LocalDate checkOutDate,
            String status) {
    }
}

