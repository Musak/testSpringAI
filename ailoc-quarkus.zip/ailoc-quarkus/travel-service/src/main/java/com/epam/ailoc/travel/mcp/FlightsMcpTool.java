package com.epam.ailoc.travel.mcp;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

import com.epam.ailoc.travel.model.Flight;
import com.epam.ailoc.travel.repository.FlightRepository;

import io.quarkiverse.mcp.server.Tool;
import io.quarkiverse.mcp.server.ToolArg;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class FlightsMcpTool {

    @Inject
    FlightRepository flightRepository;

    @Tool(
        name = "search_flights",
        description = "Search for flights by departure city, arrival city, and departure date. Returns a list of available flights matching the criteria in JSON format."
    )
    public List<Flight> searchFlights(
            @ToolArg(description = "Departure city name") String departure,
            @ToolArg(description = "Arrival city name") String arrival,
            @ToolArg(description = "Departure date (YYYY-MM-DD format)") String departureDate) {

        LocalDate date = null;
        if (departureDate != null || !departureDate.trim().isEmpty()) {
            try {
                date = LocalDate.parse(departureDate.trim());
            } catch (DateTimeParseException e) {
                // Invalid date format, date remains null
            }
        }

        return flightRepository.search(departure, arrival, date);
    }
}
