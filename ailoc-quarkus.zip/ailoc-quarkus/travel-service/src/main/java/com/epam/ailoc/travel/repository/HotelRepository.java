package com.epam.ailoc.travel.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.epam.ailoc.travel.model.Hotel;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class HotelRepository implements PanacheRepository<Hotel> {

    public List<Hotel> search(String city, String country, Double minRating) {
        StringBuilder query = new StringBuilder("1=1");
        Map<String, Object> params = new HashMap<>();

        if (city != null && !city.isBlank()) {
            query.append(" and lower(city) = :city");
            params.put("city", city.toLowerCase());
        }
        if (country != null && !country.isBlank()) {
            query.append(" and lower(country) = :country");
            params.put("country", country.toLowerCase());
        }
        if (minRating != null) {
            query.append(" and rating >= :minRating");
            params.put("minRating", minRating);
        }

        return params.isEmpty() ? listAll() : find(query.toString(), params).list();
    }
}

