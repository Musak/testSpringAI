# LO AI Sandbox Application

This project implements a Retrieval-Augmented Generation (RAG) solution using Quarkus, LangChain4j, PostgreSQL with the `pgvector` extension, and a custom `Assistant` component. The application allows users to add textual documents to a vector store and then query the RAG system to generate enhanced responses based on the stored information.

## Features

*   **Document Ingestion**: Add textual documents to the `pgvector` store via text or file upload.
*   **Contextual Question Answering**: Query the RAG system, which retrieves relevant documents and augments the prompt for the AI model to provide more informed answers.
*   **LangChain4j Integration**: Leverages LangChain4j for seamless integration with large language models and vector store functionalities.
*   **PostgreSQL with pgvector**: Uses PostgreSQL as the database with the `pgvector` extension for efficient similarity searches on vector embeddings.
*   **Travel Assistant**: AI-powered travel assistant that can search hotels, flights, and create bookings through natural language conversations.
*   **Travel Services**: RESTful API for managing hotels, flights, and bookings.

## Prerequisites

Before running this application, ensure you have the following installed:

*   **Java Development Kit (JDK)**: Version 21 or higher (project uses JDK 21).
*   **Apache Maven**: Apache Maven 3.9.9 or higher for building and managing the project.
*   **Docker and Docker Compose**: For running the entire stack (recommended).

## Installation

### Option 1: Docker Compose (Recommended)

This is the easiest way to run the entire application stack.

1. **Clone the Repository**:
   ```bash
   git clone <repository-url>
   cd ailoc-quarkus
   ```

2. **Environment Variable Setup (.env)**:
   
   Create a `.env` file in the project root with your API key:
   ```env
   YOUR_API_KEY=your-api-key-here
   OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:3000/api/public/otel
   OTEL_EXPORTER_OTLP_HEADERS=Authorization=Basic <your-base64-credentials>
   ```
   
   Replace `your-api-key-here` with your actual API key. The OpenTelemetry variables are optional and only needed if you want to use Langfuse for observability.

3. **Start All Services**:
   ```bash
   docker-compose --profile local-ui --profile local-quarkus up -d --build
   ```
   
   This will start:
   - PostgreSQL with pgvector on port `7432`
   - Quarkus main application on port `8080`
   - Travel service on port `8081`
   - Streamlit frontend on port `8501`

4. **Stop All Services**:
   ```bash
   docker-compose --profile local-ui --profile local-quarkus down
   ```

### Option 2: Local Development

1. **Clone the Repository**:
   ```bash
   git clone <repository-url>
   cd ailoc-quarkus
   ```

2. **Database Setup**:
   
   Start PostgreSQL with pgvector using Docker:
   ```bash
   docker run --name postgres-pgvector \
     -e POSTGRES_PASSWORD=ragpassword \
     -e POSTGRES_USER=raguser \
     -e POSTGRES_DB=rag_database_quarkus \
     -p 7432:5432 \
     -d pgvector/pgvector:0.8.0-pg17
   ```
   
   The application will automatically create the vector store table on startup.

3. **Configuration**:
   
   Update `src/main/resources/application.properties` with your database connection and API key:
   ```properties
   quarkus.datasource.jdbc.url=jdbc:postgresql://localhost:7432/rag_database_quarkus
   quarkus.datasource.username=raguser
   quarkus.datasource.password=ragpassword
   quarkus.langchain4j.openai.api-key=your-api-key-here
   ```

4. **Run the Application**:
   ```bash
   ./mvnw quarkus:dev
   ```
   
   The application will be available at `http://localhost:8080`.

5. **Run the Travel Service** (in a separate terminal):
   ```bash
   cd travel-service
   ./mvnw quarkus:dev
   ```
   
   The travel service will be available at `http://localhost:8081`.

## API Endpoints and Example Calls

### RAG (Retrieval-Augmented Generation) Endpoints

#### 1. Add Text Document
Add a new document to the vector store:
```bash
curl -X POST http://localhost:8080/add-text \
  -H "Content-Type: application/json" \
  -d '{
    "content": "The capital of France is Paris. It is known for the Eiffel Tower and the Louvre Museum.",
    "metadata": {
      "source": "manual",
      "topic": "geography"
    }
  }'
```

#### 2. Upload File Document
Upload a file to be stored in the vector store:
```bash
curl -F "file=@/path/to/your/document.txt" \
  http://localhost:8080/add-document
```

#### 3. Ask the Assistant
Query the RAG system with a question:
```bash
curl -X POST http://localhost:8080/ask \
  -H "Content-Type: application/json" \
  -d '{
    "query": "What is the capital of France?"
  }'
```

**Response:**
```json
{
  "answer": "The capital of France is Paris..."
}
```

### Travel Service Endpoints

The travel service runs on port `8081` and provides endpoints for hotels, flights, and bookings.

#### 1. Search Hotels
```bash
curl -X GET "http://localhost:8081/travel/hotels?city=Budapest&minRating=4.0" \
  -H "Accept: application/json"
```

**Query Parameters:**
- `city` (optional): Filter by city name
- `country` (optional): Filter by country name
- `minRating` (optional): Minimum hotel rating (e.g., 4.0)

#### 2. Search Flights
```bash
curl -X GET "http://localhost:8081/travel/flights?departure=New%20York&arrival=Budapest&departureDate=2025-12-24" \
  -H "Accept: application/json"
```

**Query Parameters:**
- `departure` (optional): Departure city
- `arrival` (optional): Arrival city
- `departureDate` (optional): Departure date in YYYY-MM-DD format

#### 3. Create Booking
Create a booking that links a hotel and flight:
```bash
curl -X POST http://localhost:8081/travel/bookings \
  -H "Content-Type: application/json" \
  -d '{
    "hotelId": 1,
    "flightId": 1,
    "travelerName": "Ada Lovelace",
    "travelerEmail": "ada@example.com",
    "tripName": "Business Trip",
    "checkInDate": "2025-02-01",
    "checkOutDate": "2025-02-05",
    "status": "NEW"
  }'
```

### Travel Assistant Endpoint

The travel assistant provides an AI-powered conversational interface for travel planning. It maintains conversation context using a `conversationId`.

#### Basic Travel Query
```bash
curl -X POST http://localhost:8080/travel/assistant \
  -H "Content-Type: application/json" \
  -d '{
    "query": "I want to travel to Budapest",
    "conversationId": "user-123"
  }'
```

**Response:**
```json
{
  "answer": "I'd be happy to help you plan your trip to Budapest...",
  "conversationId": "user-123"
}
```

#### Multi-Step Travel Planning Example

**Step 1: Initial Travel Request**
```bash
curl -X POST http://localhost:8080/travel/assistant \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Hello, I am currently in Frankfurt and want to travel to Budapest on 2025-12-25. Taxi to airport is 100 euro, from Frankfurt airport to Budapest is 200 eur. What is the total amount that I have to spend on this travel? What is the Hotel name where I will be sleeping? What is the flight that I will use for this trip?",
    "conversationId": "user-123"
  }'
```

**Step 2: Provide Additional Details**
```bash
curl -X POST http://localhost:8080/travel/assistant \
  -H "Content-Type: application/json" \
  -d '{
    "query": "departure date is 2025-12-24 from Frankfurt and I will travel alone, any hotel is good for me",
    "conversationId": "user-123"
  }'
```

**Step 3: Proceed with Booking**
```bash
curl -X POST http://localhost:8080/travel/assistant \
  -H "Content-Type: application/json" \
  -d '{
    "query": "proceed booking hotel, the rest I will manage",
    "conversationId": "user-123"
  }'
```

**Important Notes:**
- The `conversationId` is required for all travel assistant requests
- Use the same `conversationId` throughout a conversation to maintain context
- The assistant can search hotels, flights, calculate costs, and create bookings based on natural language queries

## Application Architecture

- **Main Application** (Port 8080): Quarkus application with RAG capabilities and travel assistant
- **Travel Service** (Port 8081): Separate Quarkus microservice for travel-related operations
- **PostgreSQL with pgvector** (Port 7432): Vector database for document embeddings
- **Frontend** (Port 8501): Streamlit UI for interacting with the application

## Troubleshooting

*   **`pgvector` extension not found**: Make sure you're using the `pgvector/pgvector` Docker image or have installed the pgvector extension in your PostgreSQL database.
*   **Connection refused errors**: Ensure all services are running and ports are not already in use.
*   **API key errors**: Verify your API key is correctly set in the environment variables or `application.properties`.
*   **Travel service not accessible**: Make sure the travel service is running on port 8081 and the main application can reach it (check `FLIGHTS_MCP_SERVER` configuration).

## Configuration

Key configuration properties in `src/main/resources/application.properties`:

- `quarkus.datasource.jdbc.url`: PostgreSQL connection URL
- `quarkus.langchain4j.openai.api-key`: OpenAI API key
- `quarkus.langchain4j.openai.base-url`: OpenAI API base URL
- `app.similarity.top-k`: Number of similar documents to retrieve (default: 3)
- `app.similarity.threshold`: Similarity threshold for document matching (default: 0.2)
- `FLIGHTS_MCP_SERVER`: Travel service MCP endpoint (default: http://localhost:8081/mcp)
